import { observer } from 'mobx-react-lite';
import React, { useEffect } from 'react';
import { IInputs } from '../../../api';
import { useRootContext } from '../../../RootStore';
import AppState from '../../../appState';
import RecordingComponent from '../components/RecordingComponent';
import DataCollectionStore from '../store';

const Recording = () => {
  const root = useRootContext();
  const appState: AppState = root.appState;
  const dataCollectionStore: DataCollectionStore = root.dataCollectionStore;

  useEffect(() => {
    document.title = root.appState.locale.getString('titles.recording');
  });

  return (
    <RecordingComponent
      maxDuration={dataCollectionStore.duration}
      minDuration={1}
      inputs={dataCollectionStore.inputs as IInputs}
      sessionDateTime={appState.formatSessionTime(
        +dataCollectionStore.recordingSession,
      )}
    />
  );
};

export default observer(Recording);
