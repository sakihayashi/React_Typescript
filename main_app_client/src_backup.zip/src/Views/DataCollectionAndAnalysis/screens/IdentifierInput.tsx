import {
  Button,
  FormControl,
  Grid,
  MenuItem,
  TextField,
  Typography,
} from '@mui/material';
import LocaleStore from '@otosense/locale';
import { observer } from 'mobx-react-lite';
import React, { ChangeEvent, useEffect } from 'react';
import apiRequest, { APIS } from '../../../api';
import { useRootContext } from '../../../RootStore';
import AppState from '../../../appState';
import AssetTypeStore from '../../../assetTypeStore';
import { ReviewSessionsStore } from '../../ReviewSessions';
import DataCollectionStore from '../store';

export const IdentifierInput = () => {
  const root = useRootContext();
  const appState: AppState = root.appState;
  const assetTypeStore: AssetTypeStore = root.assetTypeStore;
  const reviewSessionsStore: ReviewSessionsStore = root.reviewSessionsStore;
  const dataCollectionStore: DataCollectionStore = root.dataCollectionStore;
  const locale: LocaleStore = appState.locale;
  const headers = [
    locale.getString('testing.assetType'),
    locale.getString('testing.assetVariant'),
    locale.getString('testing.assetChannel'),
  ];
  const options = [
    assetTypeStore.assetTypeNames,
    assetTypeStore.variantIds,
    assetTypeStore.variantChannelNames.map((data) => data.name),
  ];
  const values = [
    assetTypeStore.selectedAssetType
      ? (assetTypeStore.selectedAssetType.name as string)
      : 'None',
    assetTypeStore.selectedVariant
      ? (assetTypeStore.selectedVariant._id as string)
      : 'None',
    assetTypeStore.selectedChannel
      ? (assetTypeStore.selectedChannel.name as string)
      : 'None',
  ];

  useEffect(() => {
    document.title = locale.getString('titles.selectAssetType');
  });

  useEffect(() => {
    dataCollectionStore.setIsStopped(false);
    dataCollectionStore.setIsRecordingDone(false);
    // auto select asset used in latest session
    reviewSessionsStore
      .filteredSessions(null, null, null, null, null, null, null, 1, null)
      .then(([[latestResult]]) => {
        if (latestResult == null) {
          return;
        }
        if (assetTypeStore.assetTypes) {
          const latestAssetType = assetTypeStore.assetTypes.find(
            (assetType) => assetType.name === latestResult.asset_type
          );
          if (latestAssetType) {
            assetTypeStore.selectAssetTypeById(latestAssetType._id);
          }
        }

        assetTypeStore.selectVariantById(latestResult.asset_variant);

        if (
          assetTypeStore.selectedVariant &&
          assetTypeStore.selectedVariant.channels
        ) {
          const latestChannel = assetTypeStore.selectedVariant.channels.find(
            (channel) => channel._id === latestResult.channel_id
          );
          if (latestChannel) {
            assetTypeStore.selectChannelByName(latestChannel.name);
          }
        }
      });
  }, []);

  const nextScreen: VoidFunction = () => {
    if (!assetTypeStore.ready) {
      return;
    }
    appState.setIsLoading(true);
    assetTypeStore.setInstanceName('' + Date.now());
    return apiRequest(APIS.START_TESTING, {
      inputs: {
        asset_type: assetTypeStore.selectedAssetType.name,
        asset_variant: assetTypeStore.selectedVariant._id,
        channel: assetTypeStore.selectedChannel._id,
        instance: assetTypeStore.instanceName,
        pipeline_id: assetTypeStore.selectedChannel.dpp_id,
      },
    });
  };

  const selectAssetType = (e: ChangeEvent<HTMLTextAreaElement>) => {
    assetTypeStore.selectAssetTypeByName(e.target.value as string, true);
  }

  const selectVariant = (e: ChangeEvent<HTMLTextAreaElement>) => {
    assetTypeStore.selectVariantById(e.target.value as string, true);
  }

  const selectChannel = (e: ChangeEvent<HTMLTextAreaElement>) => {
    assetTypeStore.selectChannelByName(e.target.value as string);
  }

  const handleChanges = [selectAssetType, selectVariant, selectChannel];
  const refreshAssetTypes = () => {
    return assetTypeStore.fetchAssetTypes();
  };
  const cleanup = (id: NodeJS.Timer) => {
    clearInterval(id);
  }
  useEffect(() => {
    const timerId = setInterval(refreshAssetTypes, 5000);
    return cleanup(timerId);
  }, []);

  return (
    <>
      <Grid container spacing={1}>
        {headers.map((header, i) => {
          let helperText: string = null;
          if (i === 2 && values[i]) {
            // selecting for pipeline
            const channelData = assetTypeStore.variantChannelNames.find(
              (data) => data.name === values[i]
            );
            if (channelData && channelData.dpp_id) {
              // display dppUpdated time
              helperText = `${locale.getString(
                'testing.dppUpdated'
              )}: ${appState.formatSessionTime(channelData.dpp_build_time)}`;
              assetTypeStore.setSelectedDppBuiltTime(
                channelData.dpp_build_time
              );
            } else {
              // display dataAcquisitionOnly
              helperText = locale.getString('testing.dataAcquisitionOnly');
              assetTypeStore.setSelectedDppBuiltTime(null);
            }
          }
          return (
            <Grid item xs={4} key={`form-identifier-input-${header}-${i}`}>
              <FormControl sx={{ minWidth: '100%' }} fullWidth={true}>
                <Typography variant="overline">{header}</Typography>
                <TextField
                  select
                  value={values[i]}
                  onChange={handleChanges[i]}
                  helperText={helperText}
                >
                  {options[i] &&
                    options[i].map((name, j) => {
                      return (
                        <MenuItem
                          key={`assettype-option-${name}-${j}`}
                          value={name}
                        >
                          {name}
                        </MenuItem>
                      );
                    })}
                </TextField>
              </FormControl>
            </Grid>
          );
        })}
      </Grid>
      <Button
        size="large"
        sx={{ mt: 2, float: 'right' }}
        onClick={nextScreen}
        disabled={!assetTypeStore.ready}
      >
        {locale.getString('testing.start')}
      </Button>
    </>
  );
};

export default observer(IdentifierInput);
