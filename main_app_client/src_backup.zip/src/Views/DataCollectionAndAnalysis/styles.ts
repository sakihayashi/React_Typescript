import { styled } from '@mui/material/styles';

export const ScreenMain = styled('main')(({theme}) => ({
  width: '100%',
  height: '100%',
}));
