import {
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
} from '@mui/material';
import LocaleStore from '@otosense/locale';
import { observer } from 'mobx-react-lite';
import React from 'react';
import { useRootContext } from '../../../RootStore';
import AppState from '../../../appState';
import AssetTypeStore from '../../../assetTypeStore';
import AssetComb from '../../components/AssetComb';
import DataCollectionStore from '../store';

const RecordingInfo = () => {
  const root = useRootContext();
  const appState: AppState = root.appState;
  const locale: LocaleStore = appState.locale;
  const dataCollectionStore: DataCollectionStore = root.dataCollectionStore;
  const assetTypeStore: AssetTypeStore = root.assetTypeStore;
  const testStatus = dataCollectionStore.testStatus;
  const quality_score = testStatus.quality_score;
  const quality_score_threshold = testStatus.quality_score_threshold;
  const threshold: number = quality_score_threshold || 5;
  const isPass = quality_score >= threshold;

  const passFail = [
    locale.getString('reviewSessions.pass'),
    locale.getString('reviewSessions.fail'),
  ];
  const headers = [
    locale.getString('literals.asset'),
    locale.getString('testing.latestSessionNum'),
    locale.getString('testing.LatestQualityScore'),
    locale.getString('testing.passFail'),
  ];
  const headersNoDpp = [
    locale.getString('literals.asset'),
    locale.getString('testing.sessionCount'),
  ];

  const stopTestingManual = () => {
    dataCollectionStore.stopTesting();
    dataCollectionStore.setIsStopped(true);
  };
  const exitRecording: () => Promise<void> = () => {
    return dataCollectionStore.nextScreen().then(() => {
      dataCollectionStore.setSessionHistory([]);
      dataCollectionStore.setHistoryMinus1([]);
      dataCollectionStore.setIsRecordingDone(false);
    });
  };
  const assetCombination: JSX.Element = (
    <TableCell>
      <AssetComb />
      {assetTypeStore.selectedDppBuiltTime && (
        <>
          <p>{locale.getString('testing.dppUpdated')}</p>
          <b>
            {appState.formatSessionTime(assetTypeStore.selectedDppBuiltTime)}
          </b>
        </>
      )}
    </TableCell>
  );
  const tableHeader: JSX.Element = (
    <TableHead>
      <TableRow>
        {assetTypeStore.selectedDppBuiltTime
          ? headers.map((header, i) => (
            <TableCell
              key={`qs-session-${header}`}
              sx={{ textTransform: i === 0 ? 'capitalize' : 'none' }}
            >
              {header}
            </TableCell>
          ))
          : headersNoDpp.map((header, i) => (
            <TableCell
              key={`qs-session-${header}`}
              sx={{ textTransform: i === 0 ? 'capitalize' : 'none' }}
            >
              {header}
            </TableCell>
          ))}
        <TableCell />
      </TableRow>
    </TableHead>
  );
  const tableBody: JSX.Element = (
    <TableRow>
      {assetCombination}
      {assetTypeStore.selectedDppBuiltTime ? (
        <>
          <TableCell>
            <Typography variant="h1" component="span">
              {testStatus.qs_session_num}
            </Typography>
          </TableCell>
          <TableCell>
            <Typography variant="h1" component="span">
              {typeof quality_score === 'string'
                ? quality_score
                : Math.round(+quality_score * 100) / 100}
            </Typography>
          </TableCell>
          {testStatus.qs_session_num ? (
            <TableCell>
              <Typography
                variant="h1"
                component="div"
                sx={{ color: isPass ? 'success.main' : 'error.main' }}
              >
                {isPass ? passFail[0] : passFail[1]}
              </Typography>
            </TableCell>
          ) : (
            <TableCell>{locale.getString('global.na')}</TableCell>
          )}
        </>
      ) : (
        <>
          <TableCell>
            <Typography variant="h1" component="span">
              {testStatus.start_count}
            </Typography>
          </TableCell>
        </>
      )}

      <TableCell sx={{ textAlign: 'right' }}>
        {dataCollectionStore.isStopped ? (
          <Button size="large" onClick={exitRecording}>
            {locale.getString('testing.finish')}
          </Button>
        ) : (
          <Button color="critical" size="large" onClick={stopTestingManual}>
            {locale.getString('testing.stop')}
          </Button>
        )}
      </TableCell>
    </TableRow>
  );

  return (
    <TableContainer>
      <Table sx={{ width: '100%' }}>
        {tableHeader}
        <TableBody>{tableBody}</TableBody>
      </Table>
    </TableContainer>
  );
};

export default observer(RecordingInfo);
