import {
  LinearProgress,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
} from '@mui/material';
import LocaleStore from '@otosense/locale';
import { toJS } from 'mobx';
import { observer } from 'mobx-react-lite';
import React, { useEffect } from 'react';
import { IInputs } from '../../../api';
import { useRootContext } from '../../../RootStore';
import AppState from '../../../appState';
import EmptyImg from '../../../assets/empty_state.svg';
import AssetTypeStore from '../../../assetTypeStore';
import { ToastStore } from '../../../Utility/Toast';
import { PromiseFunction, RenderFunction } from '../../../Utility/types';
import DataCollectionStore from '../store';
import RecordingInfo from './RecordingInfo';
import { LinerProgressStyle, NoDpp, RecordingContainer } from './styles';
/**
 * The following method is acceptable for little arrays (>=100k characters),otherwise you'll get exceptions as
 * RangeError : Maximum call stack size exceeded or Out of stack space.
 * However you need to know that this method doesn't play good with UTF-8 characters.
 *
 * @param myUint8Arr
 */

// function uint8arrayToStringMethod(myUint8Arr: Uint8Array | string): string {
//     return String.fromCharCode.apply(null, myUint8Arr);
// }

export interface IRecordingComponentProps {
  displayVuMeter?: boolean;
  maxDuration: number;
  minDuration: number;
  inputs: IInputs;
  sessionDateTime: string;
  getLoudnessStream?: () => Promise<ReadableStreamReader<string>>;
}

// interface FillUpProps {
//     id: string;
//     percentage: number;
// }

// function FillUp(props: FillUpProps) {
//     const style = { height: `${props.percentage}%` };
//     return
// (<div className="oto-fill-up"><div className="oto-fill-up__percentage" id={props.id} style={style} /></div>);
// }

const RecordingComponent = (props: IRecordingComponentProps) => {
  const root = useRootContext();
  const appState: AppState = root.appState;
  const dataCollectionStore: DataCollectionStore = root.dataCollectionStore;
  const assetTypeStore: AssetTypeStore = root.assetTypeStore;
  const testStatus = dataCollectionStore.testStatus;
  const locale: LocaleStore = appState.locale;
  const toastStore: ToastStore = appState.toastStore;
  console.log('testStatus', toJS(testStatus));
  // const [vuMeterPercent, setVuMeterPercent] = useState<number>(0);
  let reader: ReadableStreamReader<string>;
  let showingLoudness: boolean = false;
  let startAudioTimerID: any;
  const passText = locale.getString('reviewSessions.pass');
  const failText = locale.getString('reviewSessions.fail');

  // toast
  if (testStatus && testStatus.is_recording && testStatus.is_running) {
    const num = testStatus.start_count + 1;

    if (dataCollectionStore.lastCount === 'N/A' && num === 1) {
      dataCollectionStore.setLastCount(num);
      const text = `${locale.getString('testing.acquiringData')}
            ${locale.getString('testing.forSession')} ${num}`;
      toastStore.addToastSuccessRecording(text);
    } else if (
      dataCollectionStore.lastCount !== num &&
      dataCollectionStore.lastCount !== 'N/A'
    ) {
      dataCollectionStore.setLastCount(num);
      const text = `${locale.getString('testing.acquiringData')}
            ${locale.getString('testing.forSession')} ${num}`;
      toastStore.addToastSuccessRecording(text);
    }
  } else if (testStatus && !testStatus.is_recording && testStatus.is_running) {
    // const num = testStatus.start_count + 1;
    if (dataCollectionStore.lastCount !== 'N/A') {
      const text = `${locale.getString('testing.pausing')}`;
      toastStore.addToastInfoRecording(text);
    }
  } else if (
    testStatus &&
    !testStatus.is_running &&
    !dataCollectionStore.isRecordingDone
  ) {
    const text = `${locale.getString('testing.acquisitionDone')}`;
    toastStore.addToastInfoRecording(text);
    dataCollectionStore.setIsRecordingDone(true);
  }

  const readStreamData: PromiseFunction = () =>
    new Promise<void>((resolve) => {
      const read: VoidFunction = () => {
        reader.read().then(({ done /* , value */ }) => {
          if (done) {
            return resolve();
          }
          // const stringValue: string = uint8arrayToStringMethod(value);
          // const array = _.split(stringValue, ',');
          // array.splice(array.length - 1, 1);
          // const numbers = array.map((num) => +num);
          // _.forEach(numbers, (num: number) => {
          //     setVuMeterPercent(num);
          // });
          if (showingLoudness) {
            setTimeout(read, 1);
          } else {
            resolve();
          }
        });
      };
    });

  const renderInfoTable: RenderFunction = () => {
    return (
      <TableContainer>
        <Table sx={{ width: '100%' }}>
          <TableHead>
            <TableRow>
              <TableCell>{locale.getString('testing.dateAndTime')}</TableCell>
              <TableCell>{locale.getString('testing.sessionNum')}</TableCell>
              <TableCell>{locale.getString('global.qualityScore')}</TableCell>
              <TableCell>{locale.getString('testing.passFail')}</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {dataCollectionStore.historyMinus1 &&
              dataCollectionStore.historyMinus1.map((data, i) => {
                const score = +data.quality_score;
                const threshold = data.quality_score_threshold || 5;
                const isPass = score >= threshold;
                return (
                  <TableRow key={`history-recording${data.bt}-${i}`}>
                    <TableCell>
                      {data.session_bt &&
                        appState.formatSessionTime(data.session_bt)}
                    </TableCell>
                    <TableCell>{data.qs_session_num}</TableCell>
                    <TableCell>{Math.round(score * 100) / 100}</TableCell>
                    <TableCell
                      sx={{ color: isPass ? 'success.main' : 'error.main' }}
                      // className={isPass ? `oto-texts__color-success` :
                      //   `oto-texts__color-error`}
                    >
                      {isPass ? passText : failText}
                    </TableCell>
                  </TableRow>
                );
              })}
          </TableBody>
        </Table>
      </TableContainer>
    );
  };
    // const renderRecordingStatus: VoidFunction = () => {
    //     const { displayVuMeter } = props;
    //     // const { testStatus, appState: { isLoading } } = dataCollectionStore;
    //     const { config } = dataCollectionStore.appState;
    //     let messageComponent: JSX.Element;
    //     if (!config.show_anomalies) {
    //         messageComponent = null;
    //     } else if (testStatus.is_learning === true) {
    //         // messageComponent = (
    //         //     <div className="oto-recording__message">
    //         //     </div>
    //         // );
    //     } else if (+testStatus.detected_anomalies_count > 0) {
    //         messageComponent = (
    //             <div className="oto-recording__message">
    //                 <div className="oto-recording__message--error">
    //                     {locale.getString('testing.recordingStatus.anomalyDetected')}
    //                 </div>
    //                 <Button
    //                     onClick={goToAnomalyStoredSessions}
    //                     className="oto-recording__session-button"
    //                 >
    //                     {locale.getString('testing.viewAnomalySessions')}
    //                 </Button>
    //             </div>
    //         );
    //     } else {
    //         messageComponent = (
    //             <div className="oto-recording__message">
    //                 <div className="oto-recording__message--info">
    //                     {locale.getString('testing.recordingStatus.noAnomalyDetected')}
    //                 </div>
    //             </div>
    //         );
    //     }

  //     return (
  //         <div className="oto-recording__status">
  //             {messageComponent}
  //             {!!displayVuMeter && <div className="oto-recording__vumeter">
  //                 <FillUp id="vuMeter" percentage={vuMeterPercent}/>
  //                 <FontIcon>equalizer</FontIcon>
  //             </div>}
  //         </div>
  //     );
  // };

  useEffect(() => {
    if (props.displayVuMeter && props.getLoudnessStream) {
      startAudioTimerID = setTimeout(() => {
        props.getLoudnessStream().then((readerStream: any) => {
          reader = readerStream;
          if (reader !== null) {
            showingLoudness = true;
            // setupBlocks();
            readStreamData();
          } else {
            const { setScreenErrorMessage } = dataCollectionStore;
            setScreenErrorMessage(
              locale.getString('testing.recordingMessage.noSensor')
            );
          }
        });
      }, 200);
      clearTimeout(startAudioTimerID);
    }
  });

  return (
    <RecordingContainer>
      {!appState.isLoading && !dataCollectionStore.isStopped && (
        <LinearProgress sx={LinerProgressStyle} />
      )}
      <RecordingInfo />
      <hr />
      {assetTypeStore.selectedDppBuiltTime && renderInfoTable()}
      {!assetTypeStore.selectedDppBuiltTime && (
        <NoDpp>
          <div>
            <img
              src={EmptyImg}
              alt={locale.getString('testing.dataAcquisitionOnly')}
            />
          </div>
          <Typography variant="h3">
            {locale.getString('testing.dataAcquisitionOnly')}
          </Typography>
        </NoDpp>
      )}
    </RecordingContainer>
  );
};
export default observer(RecordingComponent);
