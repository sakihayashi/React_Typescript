import ThumbDownIcon from '@mui/icons-material/ThumbDown';
import ThumbUpIcon from '@mui/icons-material/ThumbUp';
import Button from '@mui/material/Button';
import Checkbox from '@mui/material/Checkbox';
import Stack from '@mui/material/Stack';
import TextField from '@mui/material/TextField';
import Typography from '@mui/material/Typography';
import LocaleStore from '@otosense/locale';
import { observer } from 'mobx-react-lite';
import React, { useState } from 'react';
import apiRequest, { APIS, FeedbackEnum } from '../../../api';
import { useRootContext } from '../../../RootStore';
import AppState from '../../../appState';
import { FormBox, TextIconBox } from '../../../globalStyles/otoBox';
import { PromiseFunction } from '../../../Utility/types';
import ReviewSessionsStore from '../../ReviewSessions/store';
import DataCollectionStore from '../store';
import { UserFeedbackActions } from './styles';

export interface UserFeedbackState {
  notes: string;
  passFail: FeedbackEnum;
}

export interface UserFeedbackProps {
  sessionId?: number;
  notes?: string;
  passFail?: FeedbackEnum;
  callback?: (props?: UserFeedbackProps, state?: UserFeedbackState) => void;
}

const UserFeedback = (props: UserFeedbackProps) => {
  const root = useRootContext();
  const appState: AppState = root.appState;
  const locale: LocaleStore = appState.locale;
  const dataCollectionStore: DataCollectionStore = root.dataCollectionStore;
  const reviewSessionsStore: ReviewSessionsStore = root.reviewSessionsStore;
  const { sessionId, notes, passFail, callback } = props;
  const [feedback, setFeedback] = useState({
    notes: notes || '',
    passFail: passFail || FeedbackEnum.UNSET,
  });
  const pass: VoidFunction = () =>
    setFeedback({ ...feedback, passFail: FeedbackEnum.PASS });

  const fail: VoidFunction = () =>
    setFeedback({ ...feedback, passFail: FeedbackEnum.FAIL });

  const getFeedbackComment: (
    e: React.ChangeEvent<HTMLTextAreaElement>
  ) => void = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setFeedback({ ...feedback, notes: e.target.value });
  };

  const storeUserFeedback: PromiseFunction = () => {
    const storeFeedbackArgs = {
      feedback: feedback.passFail,
      notes: feedback.notes,
      source_set_id: sessionId,
    };
    return apiRequest(APIS.STORE_FEEDBACK, storeFeedbackArgs)
      .then(() => callback(props, feedback))
      .then(reviewSessionsStore.updateCurrentPage);
  };
  const resetAndClose = () => {
    setFeedback({
      notes: notes || '',
      passFail: passFail || FeedbackEnum.UNSET,
    });
    //  dataCollectionStore.resetRecordingResults();
    reviewSessionsStore.setSelectedSessionState(null);
    dataCollectionStore.resetRecordingResults();
  };
  const labelPass = {
    inputProps: { 'aria-label': locale.getString('reviewSessions.pass') },
  };
  const labelFail = {
    inputProps: { 'aria-label': locale.getString('reviewSessions.fail') },
  };
  return (
    <FormBox mt={1}>
      <Typography variant="h5">
        {locale.getString('userFeedback.canYouProvideFeedback')}
      </Typography>
      <Stack direction="row" ml={-0.5} mb={1}>
        <TextIconBox>
          <Checkbox
            id="Pass"
            name="feedback"
            {...labelPass}
            onChange={pass}
            checked={feedback.passFail === FeedbackEnum.PASS}
          />
          <ThumbUpIcon color="success" sx={{ mr: 1 }} />
        </TextIconBox>
        <TextIconBox>
          <Checkbox
            id="Fail"
            name="feedback"
            onChange={fail}
            {...labelFail}
            checked={feedback.passFail === FeedbackEnum.FAIL}
          />
          <ThumbDownIcon color="error" />
        </TextIconBox>
      </Stack>
      <Typography variant="overline">
        {locale.getString('userFeedback.addComments')}
      </Typography>
      <TextField
        placeholder={locale.getString('util.enterText')}
        sx={{ width: '100%', height: 92 }}
        onChange={getFeedbackComment}
        value={feedback.notes}
        multiline
        rows={4}
        maxRows={4}
      />
      <UserFeedbackActions>
        <Button
          onClick={resetAndClose}
          size="medium"
          color="cancel"
          sx={{ mr: 1 }}
        >
          {locale.getString('literals.close')}
        </Button>
        <Button size="medium" onClick={storeUserFeedback}>
          {locale.getString('literals.save')}
        </Button>
      </UserFeedbackActions>
    </FormBox>
  );
};

export default observer(UserFeedback);
