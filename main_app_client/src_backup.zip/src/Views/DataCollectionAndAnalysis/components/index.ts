export { default as DiagnosisScoreComponent } from './DiagnosisScoreComponent';
export { default as RecordingComponent } from './RecordingComponent';
