import * as _ from 'lodash';
import { action, computed, IObservableArray, makeObservable, observable } from 'mobx';
import apiRequest, {
  APIS,
  IErrorResponse,
  IResourceData, IResultsData, isErrorResponse,
  TestingViews,
  TestStatus,
} from '../../api';
import AppState, { View } from '../../appState';
import { isLoading } from '../../util';
import { isSnakeCase, replaceAll } from '../../Utility';
import AbstractScreenManager, { IScreenManager } from '../../Utility/AbstractScreenManager';
import { ReviewSessionsStore } from '../../Views/ReviewSessions';

const TECHNICIAN_SCREEN_ORDER: TestingViews[] = [
  TestingViews.ASSET_SELECTION,
  TestingViews.RECORD_AND_TEST,
];

export default class DataCollectionStore extends AbstractScreenManager implements IScreenManager {
  static DEFAULT_DURATION = 5;

  @observable reviewSessionsStore: ReviewSessionsStore;
  @observable duration: number = DataCollectionStore.DEFAULT_DURATION;
  @observable recordingSession: number = null;
  @observable recordingStart: number = null;
  @observable recordingStop: number = null;
  @observable recordingResults: any = null;
  @observable resourceData: IResourceData = null;
  @observable resourceFiles = {};
  @observable isServerReady: boolean = false;
  @observable isShowingDiscardDialog: boolean = false;
  @observable testStatus: TestStatus = {
    asset_data: null,
    bt: 0,
    detected_anomalies_count: 0,
    is_learning: null,
    is_running: null,
    last_session: null,
    pipeline_name: null,
    quality_score_threshold: 5,
    start_count: null,
    is_starting: false,
    is_recording: false,
    qs_session_num: 0,
    quality_score: null,
    session_bt: null,
  };
  // @observable qualityScores: IObservableArray<number> = observable.array([]);
  @observable isStopped: boolean = false;
  @observable sessionHistory: IObservableArray<TestStatus> = observable.array([]);
  @observable historyMinus1: IObservableArray<TestStatus> = observable.array([]);
  @observable latestSessionNum: number | string = 'N/A';
  @observable lastCount: number | string = 'N/A';
  @observable isRecordingDone: boolean = false;

  constructor(appState?: AppState, reviewSessionsStore?: ReviewSessionsStore) {
    super(appState, TECHNICIAN_SCREEN_ORDER);
    makeObservable(this);
    this.reviewSessionsStore = reviewSessionsStore;
    window['dataCollection'] = this;
  }

  @action receiveReset(config: any): void {
    this.isShowingDiscardDialog = false;
    this.resourceData = null;
    this.recordingStart = null;
    this.recordingStop = null;
    this.duration = config.recording_duration || DataCollectionStore.DEFAULT_DURATION;
  }

  @action setIsStopped(state: boolean) {
    this.isStopped = state;
  }

  @action.bound setSessionHistory(testStatus: TestStatus[]) {
    this.sessionHistory.replace(testStatus);
  }

  @action.bound setHistoryMinus1(testStatus: TestStatus[]) {
    this.historyMinus1.replace(testStatus);
  }

  @action.bound setLatestSessionN(num: number | string) {
    this.latestSessionNum = num;
  }

  @action.bound setLastCount(num: number | string) {
    this.lastCount = num;
  }

  @action.bound setIsRecordingDone(state: boolean) {
    this.isRecordingDone = state;
  }

  // @action.bound resetSessionCount(): void {
  //     this.setHistoryMinus1([]);
  //     this.setSessionHistory([]);
  //     this.latestSessionNum = 'N/A';
  //     this.lastCount = 'N/A';
  //     this.isRecordingDone = false;
  // }
  @action resetRecordingResults(): void {
    this.recordingResults = null;
  }

  resetInheritingClass(): Promise<void> {
    return this.appState.getConfig()
      .then((config: any) => this.receiveReset(config));
  }

  @computed get testStatusSleepMilliseconds() {
    if (this.testStatus) {
      if (this.testStatus.is_running) {
        return 2000;  // longer breaks while tests are running
      } else if (!this.testStatus.is_running) {
        return 1000;  // more frequent when waiting for user input
      }
    }
    return 5000;  // default when test status is not updating due to an error
  }

  setTestStatus(): Promise<void> {
    return new Promise((resolve) => {
      const checkStatus: VoidFunction = () => {
        this._updateTestStatus()
          .then(() => {
            if (this.appState.view === View.DATA_COLLECTION_AND_ANALYSIS) {
              setTimeout(checkStatus, this.testStatusSleepMilliseconds);
            } else {
              resolve();
            }
          });
      };
      checkStatus();
    });
  }

  @action receiveTestStatus(testStatus: TestStatus): Promise<void> {
    if (isErrorResponse(testStatus)) {
      // if any errors getting teststatus throw error msg
      if (!isErrorResponse(this.testStatus)) {
        const response = testStatus as IErrorResponse;
        let text: string;
        if (!response.success && response.error.startsWith('test_status')) {
          // Backend connection error: "test_status: TypeError: Failed to fetch". Caused by app crash.
          text = this.appState.locale.getString('global.connectionLost');
          this.appState.toastStore.addToast({
            duration: 5000,
            severity: 'error',
            message: text,
          });
          this.appState.logout();  // logout and wait for app backend to restart
        } else {
          text = (response.message) ? `${response.error}: ${response.message}` : response.error;
          this.appState.toastStore.addToast({
            duration: 5000,
            severity: 'error',
            message: text,
          });
        }
        this.testStatus = testStatus;
      }
    } else {
      // if no error update testStatus
      this.testStatus = observable(testStatus);
      // add data for recording component
      if (this.testStatus.qs_session_num === 1) {
        this.setLatestSessionN(1);

        this.reviewSessionsStore.filterSessionById(testStatus.last_session)
          .then((results: [IResultsData[], number]) => {
            const tempTestStatus = testStatus;
            tempTestStatus.session_bt = results[0][0].bt;
            return this.setSessionHistory([tempTestStatus]);
          });
        // .then(this.reviewSessionsStore.receiveSessionById);
      }
      if (this.testStatus.qs_session_num &&
        this.testStatus.qs_session_num !== this.latestSessionNum) {
        this.setLatestSessionN(testStatus.qs_session_num);
        this.reviewSessionsStore.filterSessionById(testStatus.last_session)
          .then((results: [IResultsData[], number]) => {
            testStatus.session_bt = results[0][0].bt;
            const temp = [...this.sessionHistory];
            this.historyMinus1.replace(this.sessionHistory);
            temp.unshift(testStatus);
            this.sessionHistory.replace(temp);
          });
        // .then(this.reviewSessionsStore.receiveSessionById);
      }
      if (testStatus.is_running) {
        // change screen if still not on recording page
        if (this.screen !== TestingViews.RECORD_AND_TEST) {
          this.recordingResults = null;
          this.appState.setIsLoading(false);
          return this.nextScreen();
        }
      } else {
        // console.log('show', this.appState.config.show_results);
        if (this.appState.config.show_results &&
          this.screen === TestingViews.RECORD_AND_TEST && testStatus.last_session) {

          // commented out as no userfeedback page after recording anymore. if we put it back in, we need it.
          // return this.reviewSessionsStore.filteredSessions(
          //     null,
          //     null,
          //     null,
          //     null,
          //     null,
          //     null,
          //     null,
          //     1,
          // ).then(action((response: any) => {
          //     if (!isErrorResponse(response)) {
          //         const [sessions] = response;
          //         if (sessions.length) {
          //             const lastSessionData = sessions[0];
          //             this.recordingResults = observable(lastSessionData);
          //         }
          //     }
          //     this.appState.setIsLoading(false);
          //     return this.nextScreen();
          // }));
          this.appState.setIsLoading(false);
          this.isStopped = true;

          // return this.nextScreen();
        } else if (this.screen === TestingViews.RECORD_AND_TEST) {
          this.appState.isLoading = false;
          // this.isStopped = true;

          // return this.prevScreen();
        }
      }
    }
    return Promise.resolve();
  }

  _updateTestStatus(): Promise<any> {
    return apiRequest(APIS.TEST_STATUS).then((testStatus) => this.receiveTestStatus(testStatus));
  }

  @action.bound lastNextScreen(): void {
    this.reset();
  }

  @action.bound lastNextLabel(): string {
    return this.appState.locale.getString('util.exit');
  }

  @action.bound firstBackLabel(): string {
    return this.appState.locale.getString('util.exit');
  }

  @action onScreenChange(nextScreen: TestingViews): Promise<void> {
    return Promise.resolve();
    // if (this.screen === TestingViews.ASSET_SELECTION && nextScreen !== TestingViews.ASSET_SELECTION) {
    //     await this.submitInputFields();
    // }
    // if (this.screen === TestingViews.ASSET_SELECTION && nextScreen === TestingViews.RECORD_AND_TEST) {
    //     const ifc = await this.getNextInputField();
    //     this.defaultInputs = { ...ifc.inputs };
    // }

    // if (this.screen === TestingViews.RECORD_AND_TEST && nextScreen !== TestingViews.RECORD_AND_TEST) {
    //     // await this.stopAudio();
    // }
  }

  @action.bound @isLoading stopTesting(): Promise<void> {
    return apiRequest(APIS.STOP_TESTING, {is_blocking: true}).then(() => this._updateTestStatus());
  }

  get currentTitle(): string {
    const {locale} = this.appState;
    let title: string;
    if (this.screen === TestingViews.ASSET_SELECTION) {
      title = locale.getString('testing.waitingForNextTest');
    } else if (this.screen === TestingViews.RECORD_AND_TEST) {
      title = locale.getString('testing.readyToTest');
    } else {
      title = this.screen;
    }
    title = this.appState.getTitle(title);
    if (title != null && isSnakeCase(title)) {
      title = replaceAll(title, '_', ' ').toLowerCase();
    }
    return title;
  }

  @computed get currentsubTitle(): string {
    const {locale} = this.appState;
    let subtitle: string = '';
    if (this.screen === TestingViews.ASSET_SELECTION) {
      subtitle = locale.getString('testing.instructionsToStartTest');
    }
    return subtitle;
  }
}
