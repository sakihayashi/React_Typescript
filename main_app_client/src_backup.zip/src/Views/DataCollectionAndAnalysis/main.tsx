import Button from '@mui/material/Button';
import { observer } from 'mobx-react-lite';
import React, { useEffect } from 'react';
import { TestingViews } from '../../api';
import { useRootContext } from '../../RootStore';
import { RenderFunction } from '../../Utility/types';
import * as Screens from './screens';
import DataCollectionStore from './store';
import { ScreenMain } from './styles';

export const DataCollection = () => {
  const root = useRootContext();
  const dataCollectionStore: DataCollectionStore = root.dataCollectionStore;
  let currentScreen: TestingViews;

  const renderContent: RenderFunction = () => {
    let screenComponent: JSX.Element;

    if (dataCollectionStore.screen !== currentScreen) {
      currentScreen = dataCollectionStore.screen;
    }
    if (dataCollectionStore.screen === TestingViews.ASSET_SELECTION) {
      screenComponent = <Screens.IdentifierInput />;
    } else if (dataCollectionStore.screen === TestingViews.RECORD_AND_TEST) {
      screenComponent = <Screens.Recording />;
      // }
      // else if (dataCollectionStore.screen === TestingViews.RESULTS) {
      //   screenComponent = <Screens.DiagnosisScore />;
    } else {
      screenComponent = (
        <>
          {`Unhandled Screen: ${screen}`}
          <Button color="cancel" onClick={dataCollectionStore.prevScreen}>
            Go Back
          </Button>
          <Button onClick={dataCollectionStore.reset}>Return to Start</Button>
        </>
      );
    }
    return screenComponent;
  };

  useEffect(() => {
    dataCollectionStore.setTestStatus();
  }, []);

  return <ScreenMain>{renderContent()}</ScreenMain>;
};

export default observer(DataCollection);
