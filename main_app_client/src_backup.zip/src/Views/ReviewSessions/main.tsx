import { Backdrop, Box, Button, CircularProgress } from '@mui/material';
import LocaleStore from '@otosense/locale';
// import {toJS} from 'mobx';
import { observer } from 'mobx-react-lite';
import React, { useEffect, useState } from 'react';
import { useRootContext } from '../../RootStore';
import AppState from '../../appState';
import AssetTypeStore from '../../assetTypeStore';
import { PromiseFunction, RenderFunction } from '../../Utility/types';
import ReviewSessionsStore from '../ReviewSessions/store';
import SearchFilter from './SearchFilter';
import SessionDataDialog from './SessionDataDialog';
import SessionTable from './SessionTable';
import { ReviewSessionContainer } from './styles';

const ReviewSessions = () => {
  const root = useRootContext();
  const playbackStore = root.playbackStore;
  const appState: AppState = root.appState;
  const locale: LocaleStore = appState.locale;
  const assetTypeStore: AssetTypeStore = root.assetTypeStore;
  const reviewSessionsStore: ReviewSessionsStore = root.reviewSessionsStore;
  const [drawerState, setDrawerState] = useState<boolean>(false);
  const searchTerms = [
    locale.getString('global.assetType'),
    locale.getString('global.assetVariant'),
    locale.getString('global.date'),
    locale.getString('global.qualityScore'),
    locale.getString('global.feedback'),
  ];
  const filterTitle = locale.getString('reviewSessions.searchFilters');
  const textClear = locale.getString('reviewSessions.clear');
  const textSearch = locale.getString('reviewSessions.search');

  useEffect(() => {
    document.title = root.appState.locale.getString('titles.reviewSessions');
  });

  const uploadSessionsById: () => Promise<any> = () => {
    const checkMarkedSessionIds = new Set(reviewSessionsStore.selectedIds);

    return reviewSessionsStore
      .uploadSessionsById(Array.from(checkMarkedSessionIds))
      .then(() => {
        checkMarkedSessionIds.clear();
        reviewSessionsStore.replaceSelectedIds([]);
        // checkMarkedSessionIdsSet(checkMarkedSessionIds);
        return reviewSessionsStore.updateCurrentPage();
      });
  };

  /** Close session view */
  const backToTable: VoidFunction = () => {
    reviewSessionsStore.updateCurrentPage().then(() => {
      reviewSessionsStore.setSelectedSessionState(null);
    });
  };

  const handleFilter: PromiseFunction = () => {
    const assetFilter = assetTypeStore.selectedAssetType
      ? {
        asset_instance: assetTypeStore.instanceName
          ? assetTypeStore.instanceName
          : null, // ASSET ID
        asset_type: assetTypeStore.selectedAssetType.name, // ASSET TYPE
        asset_variant: assetTypeStore.selectedVariant
          ? assetTypeStore.selectedVariant._id
          : null,
      }
      : null;
    const { filterFeedback } = reviewSessionsStore;

    return reviewSessionsStore.setFilters(
      null,
      null, // DATE
      assetFilter,
      null, // QUALITY SCORE
      false,
      filterFeedback, // FEEDBACK
      false
    );
  };
  const toggleState = () => {
    setDrawerState(!drawerState);
  };

  const renderSearchBtn: RenderFunction = () => {
    const disableUpload = !reviewSessionsStore.selectedIds.length;
    return (
      <Box sx={{ float: 'right', marginTop: '-80px', mr: '-24px' }}>
        {reviewSessionsStore.uploading ? (
          <span>{locale.getString('reviewSessions.uploadingMessage')}</span>
        ) : (
          <Button
            disabled={disableUpload}
            color="secondary"
            size="medium"
            onClick={uploadSessionsById}
            sx={{ mr: 1 }}
          >
            {locale.getString('reviewSessions.uploadSessions')}
          </Button>
        )}
        <Button color="primary" size="medium" onClick={toggleState}>
          {locale.getString('reviewSessions.searchFilters')}
        </Button>
      </Box>
    );
  };

  useEffect(() => {
    // CRF-minor | AP | 2021-06-16
    // ReviewSession and Testing asset selection should not be the same assetTypeStore selections
    assetTypeStore.clearSelections();
    handleFilter();
    // promise.then(() => reviewSessionsStore.setAssets());
  }, []);

  useEffect(() => {
    if (!reviewSessionsStore.selectedSessionState) {
      playbackStore.forceStopPlayback();
    }
  }, [reviewSessionsStore.selectedSessionState]);

  return (
    <ReviewSessionContainer>
      {reviewSessionsStore.loading ? (
        <Backdrop
          sx={{ color: '#fff', zIndex: (theme) => theme.zIndex.drawer + 1 }}
          open={appState.isLoading}
        >
          <CircularProgress color="inherit" size={150} />
        </Backdrop>
      ) : (
      // <div className="oto-main__loading">
      //   {locale.getString('global.loadingMessage')}
      // </div>
        <>
          {renderSearchBtn()}
          <SearchFilter
            searchTerms={searchTerms}
            drawerState={drawerState}
            toggleState={toggleState}
            title={filterTitle}
            btnTxtSearch={textSearch}
            btnTxtClear={textClear}
            resetFilters={reviewSessionsStore.resetFilters}
            formatAndCallSetFilters={
              reviewSessionsStore.formatAndCallSetFilters
            }
          />
          <SessionTable />
          {!!reviewSessionsStore.selectedSessionState && (
            <SessionDataDialog backToTable={backToTable} />
          )}
        </>
      )}
    </ReviewSessionContainer>
  );
};

export default observer(ReviewSessions);
