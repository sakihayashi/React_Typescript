import { action, IObservableArray, makeObservable, observable } from 'mobx';
import apiRequest, { APIS, /* AssetData, */ FeedbackEnum, IFeedback, IResultsData, isErrorResponse } from '../../api';
import AppState from '../../appState';
import AssetTypeStore from '../../assetTypeStore';
import { handleErrorResponse, isLoading } from '../../util';

interface Filters {
  startBt?: number;
  endBt?: number;
  assetsFilter?: {
    asset_instance?: string;
    asset_type?: string;
    asset_variant?: string;
  };
  qualityThreshold?: number;
  underScoreFilter?: boolean;
  feedback?: FeedbackEnum;
  retrieveSensorData?: boolean;
}

export default class ReviewSessionsStore {
  get displayedStartBt(): number {  // BOTTOM
    if (this.displayedSessions.length) {
      return this.displayedSessions[this.displayedSessions.length - 1].bt;
    }
  }

  get displayedEndBt(): number {  // TOP
    if (this.displayedSessions.length) {
      return this.displayedSessions[0].bt;
    }
  }

  get currentPage(): number {
    return this.prevDisplayed.length + 1;
  }

  @observable displayedSessions: IResultsData[] = [];
  @observable loading = false;
  @observable uploading = false;
  @observable filters: Filters = {};
  @observable totalFilteredSessions: number = 0;
  @observable rowsPerPage: number = 10;  // filteredSessions limit
  @observable currentSessionChartType = 'peaks';
  @observable selectedSessionState: IResultsData = null;
  @observable filterStartDate: number = null;
  @observable filterEndDate: number = null;
  @observable filterScore: number = null;
  @observable filterUnderScore: boolean = false;
  @observable filterFeedback: FeedbackEnum = FeedbackEnum.ALL;
  @observable selectedIds: IObservableArray<string> = observable.array([]);
  @observable latestSession: IObservableArray<IResultsData> = observable.array([]);

  appState: AppState;
  assetTypeStore: AssetTypeStore;

  private prevDisplayed: { displayedStartBt: number, displayedEndBt: number }[] = [];

  constructor(appState?: AppState, assetTypeStore?: AssetTypeStore) {
    makeObservable(this);
    this.appState = appState;
    this.assetTypeStore = assetTypeStore;
  }

  // @action receiveAssets(assets: AssetData[]): void {
  //     this.notificationOnError(assets);
  //     this.assets.replace(assets);
  // }
  //
  // setAssets(): Promise<void> {
  //     return Controller.getAssets()
  //     .then((assets: any) => this.receiveAssets(assets));
  // }

  @handleErrorResponse @isLoading filteredSessions(
    startBt?: number,
    endBt?: number,
    assetsFilter?: any,
    qualityThreshold?: number,
    underScoreFilter?: boolean,
    feedback?: FeedbackEnum,
    retrieveSensorData?: boolean,
    limit?: number,
    sessionId?: number | number[],
  ): Promise<[IResultsData[], number]> {

    let tempFeedback = feedback || null;
    if (feedback === FeedbackEnum.ALL) {
      tempFeedback = null;
    }
    return apiRequest(APIS.FILTERED_SESSIONS, {
      assets_filter: assetsFilter,
      end_bt: endBt,
      feedback: tempFeedback,
      limit,
      quality_threshold: qualityThreshold,
      source_set_ids: sessionId,
      start_bt: startBt,
      under_quality_threshold_score: underScoreFilter === true,
    });
  }

  filterSessionById(sessionId: number): Promise<[IResultsData[], number]> {
    const tempId = sessionId + '';
    return apiRequest(APIS.FILTERED_SESSIONS, {
      limit: 1,
      source_set_ids: [tempId],
    });
  }

  @handleErrorResponse @isLoading sensorDataBase64(sessionId: number): Promise<string[]> {
    return apiRequest(APIS.GET_SESSION_SENSORS_DATA_AS_BASE64, {_id: sessionId});
  }

  @action setSelectedSessionState(data: IResultsData | null): void {
    this.selectedSessionState = data;
  }

  @action receiveFilteredSessions(results: any[]): void {
    if (results && results.length) {
      this.displayedSessions = results[0];
      if (results.length > 1) {
        this.totalFilteredSessions = results[1];
      }
    }
  }

  // @action.bound receiveSessionById(results: any[]): void {
  //     console.log('results', results);

  //     if (results && results.length) {
  //         console.log('results[0][0]', results[0][0]);
  //         const result: IResultsData = results[0][0];
  //         this.latestSession = result;
  //     }
  // }
  @action.bound setFilterValues(fieldName: string, value: number | boolean | FeedbackEnum) {
    this.filters[fieldName as string] = value;
  }

  @action.bound replaceSelectedIds(ids: string[]) {
    this.selectedIds.replace(ids);
  }

  @action setFilters(startBt?: number, endBt?: number, assetsFilter?: Filters['assetsFilter'],
                     qualityThreshold?: number, underScoreFilter?: boolean, feedback?: FeedbackEnum,
                     retrieveSensorData?: boolean): Promise<any> {
    this.filters = observable({
      assetsFilter, endBt, feedback, qualityThreshold, retrieveSensorData, startBt, underScoreFilter,
    });
    return this.filteredSessions(
      startBt, endBt, assetsFilter, qualityThreshold,
      underScoreFilter, feedback, retrieveSensorData, this.rowsPerPage, null)
      .then((results: any) => this.receiveFilteredSessions(results));
  }

  @action.bound formatAndCallSetFilters() {
    const {selectedAssetType, selectedVariant} = this.assetTypeStore;
    let tempFeedbackVal = this.filterFeedback;
    if (this.filterFeedback === FeedbackEnum.ALL) {
      tempFeedbackVal = null;
    }
    const assetFilter = {
      asset_type: selectedAssetType ? selectedAssetType.name : null,
      asset_variant: selectedVariant ? selectedVariant._id : null,
      asset_instance: null,
    };

    this.setFilters(
      this.filterStartDate, this.filterEndDate, assetFilter,
      this.filterScore, this.filterUnderScore, tempFeedbackVal,
    );
  }

  @action.bound resetFilters() {
    this.assetTypeStore.selectedAssetType = null;
    this.assetTypeStore.selectedVariant = null;
    this.assetTypeStore.assetTypeName = '';
    this.assetTypeStore.assetVariantName = '';
    this.filterEndDate = null;
    this.filterStartDate = null;
    this.filterScore = null;
    this.filterFeedback = FeedbackEnum.ALL;
    this.filterUnderScore = false;
    this.formatAndCallSetFilters();
  }

  @action.bound setFilterScore(score: number) {
    this.filterScore = score;
  }

  @action.bound setFilterEndDate(endDate: number) {
    this.filterEndDate = endDate;
  }

  @action.bound setFilterStartDate(startDate: number) {
    this.filterStartDate = startDate;
  }

  @action.bound setFilterUnderScore(state: boolean) {
    this.filterUnderScore = state;
  }

  @action.bound setFeedbackFilter(num: FeedbackEnum | null): void {
    this.filterFeedback = num;
  }

  @action.bound updateCurrentPage() {
    const {
      assetsFilter, feedback, qualityThreshold, retrieveSensorData, underScoreFilter,
    } = this.filters;
    let tempFeedback: FeedbackEnum | null = feedback;
    if (feedback === FeedbackEnum.ALL) {
      tempFeedback = null;
    }
    return this.filteredSessions(
      this.displayedStartBt, this.displayedEndBt, assetsFilter,
      qualityThreshold, underScoreFilter, tempFeedback, retrieveSensorData, this.rowsPerPage)
      .then((results: any) => this.receiveFilteredSessions(results.slice(0, 1)));
  }

  nextPage() {
    const {
      assetsFilter, feedback, qualityThreshold, retrieveSensorData, startBt, underScoreFilter,
    } = this.filters;
    this.prevDisplayed.push({
      displayedEndBt: this.displayedEndBt,
      displayedStartBt: this.displayedStartBt,
    });
    // const end_bt = this.displayedStartBt - 1;
    // const limit = this.rowsPerPage;
    // console.log({startBt, end_bt, assetsFilter, qualityThreshold, underScoreFilter, feedback,
    //              retrieveSensorData, limit});

    return this.filteredSessions(
      startBt, this.displayedStartBt - 1, assetsFilter,
      qualityThreshold, underScoreFilter, feedback, retrieveSensorData, this.rowsPerPage)
      .then((results: any) => {
        this.receiveFilteredSessions(results.slice(0, 1));
      });
  }

  prevPage() {
    const {
      assetsFilter, feedback, qualityThreshold, retrieveSensorData, underScoreFilter,
    } = this.filters;
    const {displayedEndBt, displayedStartBt} = this.prevDisplayed.pop();
    return this.filteredSessions(
      displayedStartBt, displayedEndBt, assetsFilter,
      qualityThreshold, underScoreFilter, feedback, retrieveSensorData, this.rowsPerPage)
      .then((results: any) => {
        this.receiveFilteredSessions(results.slice(0, 1));
      });
  }

  @action receiveUploadSessions(response: any[]) {
    this.uploading = false;
    if (!isErrorResponse(response)) {
      this.uploadNotification();
    }
    console.log('response', response);

    return response;
  }

  @action.bound @handleErrorResponse uploadSessionsById(sessionIds: string[]) {
    this.uploading = true;
    return apiRequest(APIS.UPLOAD_SESSIONS_BY_ID, {sessions_to_upload_ids: sessionIds})
      .then((response: any) => this.receiveUploadSessions(response));
  }

  storeUserFeedback(sessionIds: number | number[], feedback: IFeedback) {
    return apiRequest(APIS.STORE_FEEDBACK, {
      feedback: feedback.feedback,
      note: feedback.feedback_comment,
      source_set_id: sessionIds,
    });
  }

  @action setChartType(chartType: string): void {
    this.currentSessionChartType = chartType;
  }

  uploadNotification(): void {
    this.appState.toastStore.addToast({
      duration: 5000,
      severity: 'success',
      message: 'Session uploaded successfully',
    });
  }
}
