import React from 'react';
import FileDownloadIcon from '@mui/icons-material/FileDownload';
import PauseCircleIcon from '@mui/icons-material/PauseCircle';
import PlayCircleIcon from '@mui/icons-material/PlayCircle';
import SkipNextIcon from '@mui/icons-material/SkipNext';
import SkipPreviousIcon from '@mui/icons-material/SkipPrevious';
import Button from '@mui/material/Button';
import IconButton from '@mui/material/IconButton';
import LocaleStore from '@otosense/locale';
import { AudioChannel, TimeChannel } from '@otosense/multi-time-vis';
import { observer } from 'mobx-react-lite';
import { ReviewSessionsStore } from '.';
import { useRootContext } from '../../RootStore';
import { intArrayFromBase64 } from '../../Utility/functions';
import { PlaybackContainer, PlaybackRow } from './styles';

const SensorData = () => {
  const root = useRootContext();
  const reviewSessionsStore: ReviewSessionsStore = root.reviewSessionsStore;
  const locale: LocaleStore = root.appState.locale;
  const playbackStore = root.playbackStore;
  const base64Data = playbackStore.base64Data;
  const downloadParametersBase64 = playbackStore.downloadParametersBase64;
  const nextPlayback = playbackStore.nextPlayback;
  const prevPlayback = playbackStore.prevPlayback;
  const togglePlayback = playbackStore.togglePlayback;

  const renderTimeChannel: (sensorDataBase64: string[]) => JSX.Element = (
    sensorDataBase64: string[]
  ) => {
    const playbackIndex = playbackStore.playbackIndex;
    const currentChartType = reviewSessionsStore.currentSessionChartType;
    const audioBuffer: Uint8Array = intArrayFromBase64(
      sensorDataBase64[playbackIndex]
    );
    // const audioBuffer: Uint8Array = undefined;

    const audioChannel: AudioChannel = {
      buffer: audioBuffer.buffer,
      chartType: currentChartType,
      normalize: true,
      type: 'audio',
    };
    const sampleRate: number = new Uint32Array(
      audioBuffer.slice(24, 28).buffer
    )[0];
    const sampleWidth: number =
      new Uint16Array(audioBuffer.slice(34, 36).buffer)[0] / 8;

    return (
      <TimeChannel
        channel={audioChannel}
        bt={0}
        tt={(audioBuffer.length / (sampleWidth * sampleRate)) * 1000}
        height={100}
        indicatorX={playbackStore.progressRatio}
        leftX={0}
      />
    // <>
    // { audioBuffer && audioBuffer.length ?
    //   (
    //     <TimeChannel
    //       channel={audioChannel}
    //       bt={0}
    //       tt={audioBuffer.length / (sampleWidth * sampleRate) * 1000}
    //       height={100}
    //       indicatorX={playbackStore.progressRatio}
    //       leftX={0}
    //     />
    //   )
    //   :
    //     (<div />)
    // };
    // </>
    );
  };
  if (!base64Data || !base64Data.length) {
    return <div />;
  }

  try {
    return (
      <>
        <PlaybackContainer>
          <PlaybackRow>
            {base64Data && base64Data.length > 1 && (
              <IconButton onClick={prevPlayback}>
                <SkipPreviousIcon />
              </IconButton>
            )}
            <IconButton onClick={togglePlayback}>
              {playbackStore.playing ? <PauseCircleIcon /> : <PlayCircleIcon />}
            </IconButton>
            {base64Data && base64Data.length > 1 && (
              <IconButton onClick={nextPlayback}>
                <SkipNextIcon />
              </IconButton>
            )}
            <a {...downloadParametersBase64()}>
              <IconButton>
                <FileDownloadIcon />
              </IconButton>
            </a>
          </PlaybackRow>
          <div>
            <Button
              variant={
                reviewSessionsStore.currentSessionChartType === 'peaks'
                  ? 'contained'
                  : 'outlined'
              }
              onClick={() => reviewSessionsStore.setChartType('peaks')}
            >
              {locale.getString('reviewSessions.waveform')}
            </Button>
            <Button
              variant={
                reviewSessionsStore.currentSessionChartType === 'peaks'
                  ? 'outlined'
                  : 'contained'
              }
              onClick={() => reviewSessionsStore.setChartType('spectrogram')}
            >
              {locale.getString('reviewSessions.spectrogram')}
            </Button>
          </div>
        </PlaybackContainer>
        {base64Data && base64Data.length && renderTimeChannel(base64Data)}
      </>
    );
  } catch (e) {
    console.error('ERROR RENDERING SENSOR DATA');
    console.error(e);
    console.error('sensorDataBase64', base64Data);
    return <div />;
  }
};
export default observer(SensorData);
