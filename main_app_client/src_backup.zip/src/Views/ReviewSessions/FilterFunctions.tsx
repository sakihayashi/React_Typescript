import {
  Autocomplete,
  Box,
  FormControl,
  FormControlLabel,
  MenuItem,
  Radio,
  RadioGroup,
  Select,
  SelectChangeEvent,
  TextField,
  Typography,
} from '@mui/material';
import LocaleStore from '@otosense/locale';
import { observer } from 'mobx-react-lite';
import React from 'react';
import { FeedbackEnum } from '../../api';
import { useRootContext } from '../../RootStore';
import AppState from '../../appState';
import AssetTypeStore from '../../assetTypeStore';
import ReviewSessionsStore from './store';
import DateRangePicker, { DateRange } from '@mui/lab/DateRangePicker';
import AdapterDateFns from '@mui/lab/AdapterDateFns';
import LocalizationProvider from '@mui/lab/LocalizationProvider';

const renderSearchableFilter: (
  defaultProps: any,
  // value: string | number,
  onChange: any,
  label: string
) => JSX.Element = (defaultProps: any, onChange: any, label: string) => (
  <Autocomplete
    {...defaultProps}
    id={`filter-${label}`}
    onChange={(e: any, newValue: string | number | null) => {
      if (newValue) {
        onChange(newValue);
      } else {
        onChange('');
      }
    }}
    renderInput={(params) => (
      <TextField {...params} placeholder={label} variant="filled" />
    )}
  />
);

export const RenderAssetTypeFilter = observer(() => {
  const root = useRootContext();
  const appState: AppState = root.appState;
  const locale: LocaleStore = appState.locale;
  const assetTypeStore: AssetTypeStore = root.assetTypeStore;
  const defaultProps = {
    options: assetTypeStore.assetTypeNames,
  };
  return renderSearchableFilter(
    defaultProps,
    assetTypeStore.setAssetTypeName,
    locale.getString('settings.enterAssetType')
  );
});

export const RenderAssetVariantFilter = observer(() => {
  const root = useRootContext();
  const assetTypeStore: AssetTypeStore = root.assetTypeStore;
  const appState: AppState = root.appState;
  const locale: LocaleStore = appState.locale;
  const defaultProps = {
    options: assetTypeStore.variantIds,
  };
  return renderSearchableFilter(
    defaultProps,
    assetTypeStore.setAssetVariantName,
    locale.getString('settings.enterAssetVariant')
  );
});

export const RenderQualityDropDown = observer(() => {
  const opts: string[] = [];
  for (let i: number = 10; i > 0; i = i - 1) {
    opts.push(i.toString());
  }
  const root = useRootContext();
  const { appState, reviewSessionsStore } = root;
  const { locale } = appState;

  const changeUnderScoreState = (e: SelectChangeEvent<unknown>) => {
    const str = e.target.value;
    const state = str === 'true';
    reviewSessionsStore.setFilterUnderScore(state);
  };

  const onQualityScoreChange = (e: SelectChangeEvent<unknown>) => {
    reviewSessionsStore.setFilterScore(+e.target.value);
  };
  const above = locale.getString('reviewSessions.above');
  const under = locale.getString('reviewSessions.under');

  return (
    <>
      <FormControl component="fieldset">
        <RadioGroup
          aria-label="quality score above or below"
          defaultValue="false"
          name="filter-qs-radio"
          onChange={changeUnderScoreState}
        >
          <FormControlLabel
            value="false"
            control={<Radio />}
            label={above}
            defaultChecked
          />
          <FormControlLabel value="true" control={<Radio />} label={under} />
        </RadioGroup>
      </FormControl>
      <FormControl
        variant="filled"
        sx={{ pt: 1, minWidth: 120, mt: 1, ml: '32px' }}
      >
        <Select
          id="quality-score-filter"
          onChange={onQualityScoreChange}
          value={reviewSessionsStore.filterScore}
        >
          {opts.map((score, i) => {
            return (
              <MenuItem key={`score-${score}-${i}`} value={score}>
                {score}
              </MenuItem>
            );
          })}
        </Select>
      </FormControl>
    </>
  );
});

export const RenderFeedbackFilter = observer(() => {
  const root = useRootContext();
  const { appState, reviewSessionsStore } = root;
  const { locale } = appState;
  const titles = [
    locale.getString('reviewSessions.all'),
    locale.getString('reviewSessions.noFeedback'),
    locale.getString('reviewSessions.pass'),
    locale.getString('reviewSessions.fail'),
  ];
  const values = [
    FeedbackEnum.ALL,
    FeedbackEnum.UNSET,
    FeedbackEnum.PASS,
    FeedbackEnum.FAIL,
  ];
  const handleFeedbackFilter = (e: React.ChangeEvent<HTMLInputElement>) => {
    reviewSessionsStore.setFeedbackFilter(+e.target.value);
  };
  return (
    <FormControl component="fieldset">
      <RadioGroup
        aria-label="filter feedback"
        value={reviewSessionsStore.filterFeedback}
        name="filter-feedback-radio"
        onChange={handleFeedbackFilter}
      >
        {titles.map((title, index) => {
          return (
            <FormControlLabel
              value={values[index]}
              control={<Radio />}
              label={title}
              key={`feedback-${title}-${index}`}
            />
          );
        })}
      </RadioGroup>
    </FormControl>
  );
});

export const RenderDateFilter = observer(() => {
  const root = useRootContext();
  const reviewSessionsStore: ReviewSessionsStore = root.reviewSessionsStore;
  const appState: AppState = root.appState;
  const locale: LocaleStore = appState.locale;
  const [value, setValue] = React.useState<DateRange<Date>>([null, null]);

  const setDateInStore = (dates: Date[]) => {
    const startDate = dates[0] ? dates[0].getTime() * 1000 : null;
    const endDate = dates[1] ? dates[1].getTime() * 1000 : null;
    const oneDay = 86399999999;
    reviewSessionsStore.setFilterStartDate(startDate);
    reviewSessionsStore.setFilterEndDate(endDate + oneDay);
  };
  return (
    <LocalizationProvider dateAdapter={AdapterDateFns}>
      <DateRangePicker
        startText=""
        endText=""
        value={value}
        onChange={(newValue) => {
          setDateInStore(newValue);
          setValue(newValue);
        }}
        renderInput={(startProps, endProps) => (
          <React.Fragment>
            <Box mr={0.5}>
              <Typography variant="overline">
                {locale.getString('reviewSessions.startDate')}
              </Typography>
              <TextField {...startProps} size="small" />
            </Box>
            <Box>
              <Typography variant="overline">
                {locale.getString('reviewSessions.endDate')}
              </Typography>
              <TextField {...endProps} size="small" />
            </Box>
          </React.Fragment>
        )}
      />
    </LocalizationProvider>
  );
});
