// import { Dialog } from '@mui/material';
import { OtoModal } from '@otosense/components';
import { observer } from 'mobx-react-lite';
import React from 'react';
import { IFeedback } from '../../api';
import { useRootContext } from '../../RootStore';
import AppState from '../../appState';
import { DiagnosisScoreComponent } from '../DataCollectionAndAnalysis/components';
import UserFeedback, {
  UserFeedbackProps,
  UserFeedbackState,
} from '../DataCollectionAndAnalysis/components/UserFeedback';
import ReviewSessionsStore from '../ReviewSessions/store';
import SensorData from './SensorData';

interface IProps {
  backToTable?: VoidFunction;
}

const SessionDataDialog = (props: IProps) => {
  const { backToTable } = props;
  const root = useRootContext();
  const appState: AppState = root.appState;
  const reviewSessionsStore: ReviewSessionsStore = root.reviewSessionsStore;
  const { selectedIds } = reviewSessionsStore;
  const setFeedbackToCheckMarkedSessions: (
    userFeedbackProps: UserFeedbackProps,
    userFeedbackState: UserFeedbackState
  ) => void = (
    userFeedbackProps: UserFeedbackProps,
    userFeedbackState: UserFeedbackState
  ) => {
    let promise: Promise<any> = Promise.resolve();
    try {
      appState.setIsLoading(true);
      reviewSessionsStore.setSelectedSessionState(null);
      if (selectedIds.length > 0) {
        const { passFail, notes } = userFeedbackState;
        const sessionIds: number[] = Array.from(
          reviewSessionsStore.selectedIds
        ).map((sId) => +sId);
        const feedback: IFeedback = {
          feedback: passFail,
          feedback_comment: notes,
        };
        promise = reviewSessionsStore.storeUserFeedback(sessionIds, feedback);
      }
      promise
        .then(() => backToTable())
        .catch((e) => {
          console.error('setFeedbackToCheckMarkedSessions', e);
        })
        .then(() => appState.setIsLoading(false));
    } catch (e) {
      console.error('setFeedbackToCheckMarkedSessions', e);
    } finally {
      appState.setIsLoading(false);
    }
  };
  const { loading, selectedSessionState } = reviewSessionsStore;
  if (loading) {
    return <div />;
  }
  return (
    <OtoModal onClose={backToTable} id="session" label="Review a session">
      <>
        <DiagnosisScoreComponent results={selectedSessionState} />
        <SensorData />
        <UserFeedback
          passFail={selectedSessionState.feedback}
          notes={selectedSessionState.notes}
          sessionId={selectedSessionState._id}
          callback={setFeedbackToCheckMarkedSessions}
        />
      </>
    </OtoModal>
  );
};

export default observer(SessionDataDialog);
