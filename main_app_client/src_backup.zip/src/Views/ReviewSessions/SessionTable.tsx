import CloudDoneIcon from '@mui/icons-material/CloudDone';
import ThumbDownIcon from '@mui/icons-material/ThumbDown';
import ThumbUpIcon from '@mui/icons-material/ThumbUp';
import {
  Button,
  Checkbox,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from '@mui/material';
import LocaleStore from '@otosense/locale';
import { get } from 'lodash';
import { toJS } from 'mobx';
import { observer } from 'mobx-react-lite';
import React from 'react';
import { FeedbackEnum } from '../../api';
import { useRootContext } from '../../RootStore';
import AppState from '../../appState';
import ReviewSessionsStore from '../ReviewSessions/store';
import TablePagination from './TablePagination';

const SessionTable = () => {
  const root = useRootContext();
  const playbackStore = root.playbackStore;
  const appState: AppState = root.appState;
  const locale: LocaleStore = appState.locale;
  const reviewSessionsStore: ReviewSessionsStore = root.reviewSessionsStore;

  const headers = [
    locale.getString('global.dateAndTime'),
    locale.getString('global.assetType'),
    locale.getString('global.assetVariant'),
    locale.getString('global.qualityScore'),
    '',
    locale.getString('global.comments'),
  ];
  const renderHeaders = () => {
    return (
      <>
        {headers.map((header) => {
          return <TableCell key={`header-${header}`}>{header}</TableCell>;
        })}
      </>
    );
  };
  const selectAllforUpload = () => {
    if (
      reviewSessionsStore.selectedIds.length < reviewSessionsStore.rowsPerPage
    ) {
      const ids = reviewSessionsStore.displayedSessions.map(
        (data) => data._id + ''
      );
      reviewSessionsStore.replaceSelectedIds(ids);
    } else {
      reviewSessionsStore.replaceSelectedIds([]);
    }
  };
  const selectforUpload: (isChecked: boolean, id: any) => void = (
    isChecked: boolean,
    id: any
  ) => {
    let tempArr = toJS([...reviewSessionsStore.selectedIds]);
    if (isChecked) {
      tempArr.push(id);
    } else {
      tempArr = tempArr.filter((selectedId: string) => selectedId !== id);
    }
    const unique = Array.from(new Set(tempArr));
    reviewSessionsStore.replaceSelectedIds(unique);
  };
  const selectSession: (session: string) => void = (session: string) => {
    reviewSessionsStore
      .filteredSessions(+session, +session, null, null, null, null, true, 1)
      .then((result: any) => {
        const selectedSession: any = get(result, '[0][0]', null);
        if (selectedSession) {
          return reviewSessionsStore
            .sensorDataBase64(selectedSession._id)
            .then((sensorDataBase64: string[]) => {
              if (sensorDataBase64) {
                playbackStore.setBase64Data(sensorDataBase64);
                reviewSessionsStore.setSelectedSessionState(selectedSession);
              }
            });
        }
      });
  };
    // try {
  const listItems = reviewSessionsStore.displayedSessions.map((data, i) => {
    const session: any = data.bt;
    const isUploaded = !!data.is_uploaded;
    const isLearning = !!data.is_learning;
    let qualityScore: string;
    if (isLearning || isNaN(+data.quality_score)) {
      if (data.quality_score == null) {
        qualityScore = 'N/A';
      } else {
        qualityScore = `${data.quality_score}`;
      }
    } else {
      qualityScore = (+data.quality_score).toFixed(1);
    }

    return (
      <TableRow key={`row-${data._id}-0${i}`}>
        <TableCell padding="checkbox">
          <Checkbox
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
              selectforUpload(e.target.checked, e.target.value);
            }}
            value={data._id}
            checked={
              data._id + '' ===
              reviewSessionsStore.selectedIds.find((id) => id === data._id + '')
            }
            id={+data._id + ''}
            name="upload"
          />
        </TableCell>
        <TableCell>
          {isUploaded && <CloudDoneIcon color="disabled" />}
        </TableCell>
        <TableCell>{appState.formatSessionTime(+session)}</TableCell>
        <TableCell>{data.asset_type}</TableCell>
        <TableCell>{data.asset_variant}</TableCell>
        <TableCell>{qualityScore}</TableCell>
        <TableCell sx={{ maxWidth: 50 }}>
          {data.feedback === FeedbackEnum.PASS && (
            <ThumbUpIcon color="success" />
          )}
          {data.feedback === FeedbackEnum.FAIL && (
            <ThumbDownIcon color="error" />
          )}
        </TableCell>
        <TableCell sx={{ maxWidth: 200 }}>{data.notes}</TableCell>
        <TableCell>
          <Button variant="text" onClick={() => selectSession(session)}>
            {locale.getString('reviewSessions.seeResults')}
          </Button>
        </TableCell>
      </TableRow>
    );
  });
  return (
    <TableContainer>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell padding="checkbox">
              <Checkbox
                onClick={selectAllforUpload}
                indeterminate={
                  reviewSessionsStore.selectedIds.length &&
                  reviewSessionsStore.selectedIds.length <
                  reviewSessionsStore.rowsPerPage
                }
                checked={
                  reviewSessionsStore.selectedIds.length ===
                  reviewSessionsStore.rowsPerPage
                }
                id="uploadAll"
                aria-labelledby="uploadAll"
                name="upload"
              />
            </TableCell>
            <TableCell />
            {renderHeaders()}
            <TableCell />
          </TableRow>
        </TableHead>
        <TableBody>{listItems}</TableBody>
      </Table>
      <TablePagination />
    </TableContainer>
  );
  // } catch (e) {
  //   return (
  //     <TableContainer>
  //       <Table>
  //         <TableHead>
  //           <TableRow>
  //             <Checkbox
  //               id="selectable-rows-root-checkbox"
  //               indeterminate={
  //                 reviewSessionsStore.selectedIds.length &&
  //                 reviewSessionsStore.selectedIds.length <
  //                   reviewSessionsStore.rowsPerPage
  //               }
  //               checked={
  //                 reviewSessionsStore.selectedIds.length ===
  //                 reviewSessionsStore.rowsPerPage
  //               }
  //             />
  //             <TableCell />
  //             {renderHeaders()}
  //           </TableRow>
  //         </TableHead>
  //         <TableBody />
  //       </Table>
  //     </TableContainer>
  //   );
  // }
};

export default observer(SessionTable);
