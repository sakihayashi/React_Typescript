import React from 'react';
import { ScrollToTopBtn } from '@otosense/components';
import { observer } from 'mobx-react-lite';

import { useRootContext } from '../../RootStore';

const ScrollBtnWrapper = () => {
  const root = useRootContext();
  const { locale } = root.appState;

  return <ScrollToTopBtn text={locale.getString('global.toTop')} />;
};

export default observer(ScrollBtnWrapper);
