import Box from '@mui/material/Box';
// import Tab from '@mui/material/Tab';
// import Tabs from '@mui/material/Tabs';
import Button from '@mui/material/Button';
import LocaleStore from '@otosense/locale';
import { observer } from 'mobx-react-lite';
import React from 'react';
import { useRootContext } from '../../RootStore';
import AppState, { View } from '../../appState';
import { selectedTabStyle, tabStyle } from '../../globalStyles/tabs';

const MenuBar = () => {
  const root = useRootContext();
  const appState: AppState = root.appState;
  const locale: LocaleStore = appState.locale;
  // const dataCollectionStore: DataCollectionStore = root.dataCollectionStore;
  const VIEW_TABS: View[] = [
    View.DATA_COLLECTION_AND_ANALYSIS,
    View.REVIEW_SESSIONS,
    View.SETTINGS,
  ];
  let VIEW_TITLES = {};
  // const tabStyle = {
  //   minWidth: 155,
  //   height: 36,
  //   marginTop: 1,
  //   marginRight: 1.25,
  //   // borderBottomWidth: 4,
  //   fontFamily: '"OpenSans-Regular", sans-serif',
  //   fontSize: 18,
  //   display: 'flex',
  //   letterSpacing: 'normal',
  //   justifyContent: 'left',
  //   paddingTop: 0,
  //   paddingLeft: 0,
  //   borderBottom: '4px solid #BDBFCA',
  //   color: '#BDBFCA',
  // };
  // const selected = {...tabStyle};
  // selected.borderBottom = '4px solid #009fbd';
  // selected.color = '#101820';

  if (appState.isLoggedInVerified) {
    VIEW_TITLES = {
      [View.DATA_COLLECTION_AND_ANALYSIS]: locale.getString('global.testing'),
      [View.REVIEW_SESSIONS]: locale.getString('global.storedSessions'),
      [View.SETTINGS]: locale.getString('global.administration'),
    };
  }

  return (
    <Box sx={{ display: 'flex' }} component="nav">
      {VIEW_TABS.map((v: View, i: number) => {
        return (
          <Button
            key={`tab-${v}`}
            variant="text"
            sx={v === appState.view ? selectedTabStyle : tabStyle}
            onClick={() => appState.setView(v)}
          >
            {VIEW_TITLES[VIEW_TABS[i]]}
          </Button>
        );
      })}
    </Box>
  );
};

export default observer(MenuBar);
