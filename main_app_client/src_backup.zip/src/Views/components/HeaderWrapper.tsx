import CloudDoneIcon from '@mui/icons-material/CloudDone';
import CloudOffIcon from '@mui/icons-material/CloudOff';
import { Header } from '@otosense/components';
import LocaleStore from '@otosense/locale';
import { observer } from 'mobx-react-lite';
import * as React from 'react';
import { useRootContext } from '../../RootStore';
import AppState from '../../appState';
import HeaderLang from './HeaderLang';
import HeaderLogo from './HeaderLogo';
import {
  cloudIconStyle,
  CloudIconWrapper,
  HeaderRight,
  HeaderText,
} from './headerStyles';
import HeaderUserMenu from './HeaderUserMenu';

// import Header from './Header';
// a wrapper to pass all props the component needs

const HeaderWrapper = () => {
  const root = useRootContext();
  const appState: AppState = root.appState;
  const locale: LocaleStore = appState.locale;

  return (
    <Header>
      <React.Fragment>
        <HeaderLogo />
        <HeaderRight>
          <HeaderLang />
          <CloudIconWrapper onClick={appState.setCurrentUserSession}>
            {appState.isLoginModeOnline ? (
              <CloudDoneIcon sx={cloudIconStyle} />
            ) : (
              <CloudOffIcon sx={cloudIconStyle} />
            )}
          </CloudIconWrapper>
          <HeaderText onClick={() => appState.toggleDateTimeFormat()}>
            {appState.currentDateTime}
          </HeaderText>
          <HeaderUserMenu
            logout={appState.logout}
            textLogout={locale.getString('global.logout')}
            setCurrentTimestamp={appState.setCurrentTimestamp}
            account={appState.account}
          />
        </HeaderRight>
      </React.Fragment>
    </Header>
  );
};

export default observer(HeaderWrapper);
