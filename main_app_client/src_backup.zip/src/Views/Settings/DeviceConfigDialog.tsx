import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControl,
  FormHelperText,
  InputAdornment,
  MenuItem,
  Select,
  SelectChangeEvent,
  TableContainer,
  TextField,
  Typography,
} from '@mui/material';
import LocaleStore from '@otosense/locale';
// import { toJS } from 'mobx';
import { observer } from 'mobx-react-lite';
import React, { useState } from 'react';
import { Fields } from '../../api';
import { useRootContext } from '../../RootStore';
import AppState from '../../appState';
import AssetTypeStore from '../../assetTypeStore';
import { FlexBox, FormBox } from '../../globalStyles/otoBox';
import SettingsStore from '../../settingsStore';
import AssetCombo from '../../Views/components/AssetComb';
import SoundCardTable from './SoundCardTable';
import WebDaqTable from './WebDaqTable';

interface IProps {
  onClose: VoidFunction;
  // visible: boolean;
  // openEventDialog: VoidFunction;
}

const DeviceConfigDialog = (props: IProps) => {
  const root = useRootContext();
  const appState: AppState = root.appState;
  const locale: LocaleStore = appState.locale;
  const assetTypeStore: AssetTypeStore = root.assetTypeStore;
  const settingsStore: SettingsStore = root.settingsStore;
  const [isError, setIsError] = useState<boolean>(false);
  const [errMsg, setErrMsg] = useState<string>('');
  const minErrMsg = locale.getString('settings.minNis');
  const maxErrMsg = locale.getString('settings.maxNis');
  const [errSelectDevice, setErrSelectDevice] = useState<string>('');
  const textMin = locale.getString('settings.min') + ': ';
  const textMax = locale.getString('settings.max') + ': ';

  const goToNextScreen = () => {
    if (!settingsStore.selectedReaderName) {
      setErrSelectDevice(locale.getString('settings.selectDevice'));
    } else {
      setErrSelectDevice('');
      settingsStore.nextEditConfig();
    }
  };
  const selectDevice = (e: SelectChangeEvent) => {
    if (e.target.value !== '') {
      setErrSelectDevice('');
    }
    settingsStore.setSelectedReaderName(e.target.value);
  };

  const clearAndClose = () => {
    props.onClose();
    settingsStore.resetDeviceSettings();
    assetTypeStore.resetSelected();
  };

  const renderCommonSettings = (field: any, index: number) => {
    switch (field.type) {
    case 'multiple choice':
      const strVals = field.values.map((val: number | string) => val + '');

      return (
        <FlexBox key={field.name + index}>
          <FormBox sx={{ flexFlow: 'column nowrap' }}>
            <Typography variant="overline">
              {locale.getString(`settings.${field.name}`)}
            </Typography>
            <FormControl
              variant="filled"
              size={field.name !== 'sensor' ? 'small' : 'medium'}
              error={!assetTypeStore.perDeviceConfigs[field.name]}
            >
              <Select
                sx={{
                  // maxWidth: 315,
                  overflow: 'hidden',
                  textOverflow: 'ellipsis',
                  textTransform: 'capitalize',
                  minWidth: 150,
                  mr: 1,
                }}
                value={(() => {
                  if (!field) {
                    return '';
                  }
                  let value: string = assetTypeStore.perDeviceConfigs[field.name] + '';
                  if (!value) {
                    value = strVals[0];
                  }
                  return value;
                })()}
                name={locale.getString(`settings.${field.name}`)}
                onChange={(e: SelectChangeEvent) =>
                  assetTypeStore.setPerDeviceConfigs(field, e.target.value)
                }
                endAdornment={
                  field.name === 'sample_rate' && (
                    <InputAdornment position="end" sx={{ pr: 1 }}>
                      {' ' + locale.getString('settings.hz')}
                    </InputAdornment>
                  )
                }
              >
                {strVals &&
                  strVals.map((val, i) => {
                    return (
                      <MenuItem
                        key={`${val}-${i}`}
                        value={val}
                        sx={{ textTransform: 'capitalize' }}
                      >
                        {val}
                      </MenuItem>
                    );
                  })}
              </Select>
            </FormControl>
          </FormBox>
        </FlexBox>
      );
    case 'range':
      return (
        <FormBox sx={{ flexFlow: 'column nowrap' }} key={field.name + index}>
          <Typography variant="overline">
            {locale.getString(`settings.${field.name}`)}
          </Typography>
          <TextField
            aria-describedby="duration-input"
            required={true}
            error={isError}
            placeholder={
              assetTypeStore.perDeviceConfigs[field.name] ||
              textMin + field.values.min + ' ' + textMax + field.values.max
            }
            type="number"
            size="small"
            value={assetTypeStore.perDeviceConfigs[field.name] + '' || ''}
            onChange={(e) => {
              const num = e.target.value;
              if (num >= field.values.min && num <= field.values.max) {
                assetTypeStore.setPerDeviceConfigs(field, num);
                setIsError(false);
              } else if (num < field.values.min) {
                assetTypeStore.setPerDeviceConfigs(field, num);
                setErrMsg(minErrMsg + ' ' + field.values.min);
                setIsError(true);
              } else if (num > field.values.max) {
                assetTypeStore.setPerDeviceConfigs(field, num);
                setErrMsg(maxErrMsg + ' ' + field.values.max);
                setIsError(true);
              }
            }}
          />
          <FormHelperText sx={{ minHeight: '1rem' }}>
            {isError && errMsg}
          </FormHelperText>
        </FormBox>
      );
    default:
      return null;
    }
  };

  return (
    <Dialog open={true} onClose={props.onClose} maxWidth="lg">
      <DialogTitle>
        <Typography variant="h2" component="header" mb={1}>
          {locale.getString('settings.deviceSettings')}
        </Typography>
        <AssetCombo />
      </DialogTitle>
      <DialogContent>
        <FlexBox>
          <FormBox mr={1}>
            <Typography variant="overline">
              {locale.getString('settings.device')}
            </Typography>
            <FormControl size="small" error={errSelectDevice !== ''}>
              <Select
                // error={errSelectDevice !== ''}
                value={settingsStore.selectedReaderName}
                sx={{ textTransform: 'capitalize' }}
                name="name"
                onChange={selectDevice}
              >
                {settingsStore.deviceOptions &&
                  settingsStore.deviceOptions.map((item, i) => {
                    return (
                      <MenuItem
                        key={`${item}-${i}`}
                        value={item}
                        sx={{ textTransform: 'capitalize' }}
                      >
                        {item}
                      </MenuItem>
                    );
                  })}
              </Select>
            </FormControl>
            <FormHelperText>{errSelectDevice}</FormHelperText>
          </FormBox>
          {settingsStore.isSelected &&
            settingsStore.perDeviceFields &&
            settingsStore.perDeviceFields.map(
              (field: Fields, index: number) => {
                return renderCommonSettings(field, index);
              }
            )}
        </FlexBox>
        <hr />
        <TableContainer>
          {settingsStore.selectedReader && settingsStore.selectedReaderName === 'soundcard' && (
            <SoundCardTable />
          )}
          {settingsStore.selectedReader && settingsStore.selectedReaderName !== 'soundcard' && (
            <WebDaqTable />
          )}
        </TableContainer>
      </DialogContent>
      <DialogActions>
        <Button color="cancel" onClick={clearAndClose}>
          {locale.getString('literals.close')}
        </Button>
        <Button
          onClick={goToNextScreen}
          disabled={
            assetTypeStore.selectedChannel &&
            !isError &&
            !assetTypeStore.perDeviceConfigs.sample_rate
          }
        >
          {locale.getString('util.next')}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default observer(DeviceConfigDialog);
