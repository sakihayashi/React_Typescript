import {
  Box,
  InputAdornment,
  TextField,
  Typography,
} from '@mui/material';
import LocaleStore from '@otosense/locale';
import { toJS } from 'mobx';
import { observer } from 'mobx-react-lite';
import React, { ChangeEvent } from 'react';
import { useRootContext } from '../../../../RootStore';
import AppState from '../../../../appState';
import SettingsStore from '../../../../settingsStore';
import {
  EventHandlerContainer,
  FlexCol,
  FlexRow,
  FormStyle,
  innerContainer,
  rowTitle,
  Subtitle,
} from './styles';

const WriteLearningMode = () => {
  const root = useRootContext();
  const appState: AppState = root.appState;
  const locale: LocaleStore = appState.locale;
  const settingsStore: SettingsStore = root.settingsStore;
  const handleTextFields = (fieldName: string, val: string | number) => {
    console.log('check', fieldName, val);
    const temp = toJS(settingsStore.plc_cfg.set_learning_mode);
    temp[fieldName] = val;
    settingsStore.setPlcConfig('set_learning_mode', temp);
  };
  return(
    <EventHandlerContainer>
      <Typography variant="h3" sx={Subtitle}>
        {locale.getString('testing.dataAcquisitionOnly')}
      </Typography>
      <Box sx={innerContainer}>
        <FlexRow>
          <Typography variant="h4" sx={rowTitle}>
            {locale.getString('settings.qcValue')}
          </Typography>
          <FlexCol mr={0.5}>
            <Typography variant="overline">
              {locale.getString('literals.address')}
            </Typography>
            <TextField
              size="small"
              placeholder={locale.getString('settings.enterAddress')}
              sx={FormStyle}
              type="number"
              onChange={(e: ChangeEvent<HTMLTextAreaElement>) =>
                handleTextFields('address', +e.target.value)
              }
              InputProps={{
                startAdornment: (
                  <InputAdornment
                    position="start"
                    sx={{ marginBottom: '16px' }}
                  >
                        %MW
                  </InputAdornment>
                ),
              }}
            />
          </FlexCol>
          <FlexCol mr={0.5}>
            <Typography variant="overline">
              {locale.getString('settings.operator')}
            </Typography>
            <Typography variant="subtitle1" sx={{height: 45, display: 'flex', alignItems: 'center'}}>{locale.getString('settings.equalTo')}</Typography>
          </FlexCol>
          <FlexCol>
            <Typography variant="overline">
              {locale.getString('literals.value')}
            </Typography>
            <TextField
              size="small"
              style={FormStyle}
              placeholder="0x0001"
              type="number"
              onChange={(e: ChangeEvent<HTMLTextAreaElement>) =>
                handleTextFields('value', +e.target.value)
              }
            />
          </FlexCol>
        </FlexRow>
      </Box>
    </EventHandlerContainer>
  );
};

export default observer(WriteLearningMode);
