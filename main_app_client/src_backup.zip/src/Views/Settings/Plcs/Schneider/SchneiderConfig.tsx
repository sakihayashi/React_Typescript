import {
  Button,
  DialogActions,
  DialogContent,
  DialogTitle,
  Typography,
} from '@mui/material';
import LocaleStore from '@otosense/locale';
import { observer } from 'mobx-react-lite';
import React, { useState, useEffect } from 'react';
import { useRootContext } from '../../../../RootStore';
import AppState from '../../../../appState';
import SettingsStore from '../../../../settingsStore';
import AssetComb from '../../../components/AssetComb';
import ReadAddress from './ReadAddress';
import ReadSession from './ReadSession';
import { textCapitalize } from './styles';
import WriteReady from './WriteReady';
import WriteValue from './WriteValue';

interface IProps {
  onClose: VoidFunction;
}

const SchneiderConfig = (props: IProps) => {
  const { onClose } = props;
  const root = useRootContext();
  const appState: AppState = root.appState;
  const locale: LocaleStore = appState.locale;
  const settingsStore: SettingsStore = root.settingsStore;
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const contents = [
    <ReadSession key="plc-read-session" />,
    <ReadAddress key="plc-read-address" />,
    <WriteReady key="plc-write-ready" />,
    <WriteValue key="plc-write-val" />,
  ];
  const readOrWrite = [
    locale.getString('settings.readSettings'),
    locale.getString('settings.readSettings'),
    locale.getString('settings.writeSetting'),
    locale.getString('settings.writeSetting'),
  ];
  const cancelClose = () => {
    onClose();
  };
  const goToNext = () => {
    if (currentIndex <= contents.length) {
      setCurrentIndex(currentIndex + 1);
    }
  };
  const saveSettings = () => {
    settingsStore.saveConfig();
    onClose();
  };
  useEffect(() => {
    settingsStore.setPlcConfig('source', 'Schneider');
    settingsStore.setPlcConfig('ip_address', '127.0.0.1');
  }, []);
  return (
    <>
      <DialogTitle sx={{ flexDirection: 'column', alignItems: 'flex-start' }}>
        <Typography variant="h2" component="header" sx={{ mt: 0, mb: 1, ml: 0, mr: 0 }}>
          <span style={textCapitalize}>
            {locale.getString('settings.schneider') + ' '}
          </span>
          <span style={{ textTransform: 'uppercase' }}>
            {locale.getString('settings.plc') + ' '}
          </span>
          -<span>{readOrWrite[currentIndex]}</span>
        </Typography>
        <div>
          <AssetComb />
        </div>
      </DialogTitle>
      <DialogContent style={{ paddingBottom: 0, paddingTop: 0 }}>
        {contents[currentIndex]}
      </DialogContent>
      <DialogActions>
        <Button onClick={cancelClose} color="cancel">
          {locale.getString('literals.close')}
        </Button>
        {contents.length === currentIndex + 1 ? (
          <Button onClick={saveSettings}>
            {locale.getString('literals.save')}
          </Button>
        ) : (
          <Button onClick={goToNext}>{locale.getString('util.next')}</Button>
        )}
      </DialogActions>
    </>
  );
};
export default observer(SchneiderConfig);
