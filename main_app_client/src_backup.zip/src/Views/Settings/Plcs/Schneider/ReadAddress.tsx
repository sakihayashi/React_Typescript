// import { settings } from 'cluster';
import AddIcon from '@mui/icons-material/Add';
import DeleteIcon from '@mui/icons-material/Delete';
import {
  Box,
  Button,
  InputAdornment,
  TextField,
  Typography,
  FormControl,
  RadioGroup,
  Radio,
  Checkbox,
} from '@mui/material';
import LocaleStore from '@otosense/locale';
import { observer } from 'mobx-react-lite';
import React, { ChangeEvent, useEffect } from 'react';
import { useRootContext } from '../../../../RootStore';
import AppState from '../../../../appState';
// import AssetTypeStore from '../../../../assetTypeStore';
import SettingsStore from '../../../../settingsStore';
import {
  addButton,
  AddButtonContainer,
  deleteIcon,
  EventHandlerContainer,
  FlexCol,
  FlexRow,
  FormStyle,
  InnerContainer,
  Subtitle,
} from './styles';

const ReadAddress = () => {
  const root = useRootContext();
  const appState: AppState = root.appState;
  const locale: LocaleStore = appState.locale;
  const settingsStore: SettingsStore = root.settingsStore;
  const radioLabels: string[] = [
    locale.getString('global.variant'),
    locale.getString('global.phase'),
    locale.getString('settings.rdy'),
  ];
  const radioKeys: string[] = ['is_asset_variant', 'is_phase', 'is_readiness', 'is_display'];

  const textFieldOnChange = (val: string | number, name: string, i: number) => {
    const temp = settingsStore.read_tags;
    temp[i][name] = val;
    console.log('temp', temp);
    settingsStore.setPlcTags(temp);
  };
  const addPlcTag = () => {
    const temp = settingsStore.read_tags;
    temp.push({
      name: '',
      address: null,
      count: null,
      trigger_type_name: 'timer',
      trigger_value: settingsStore.trigger_value,
      is_readiness: false,
      is_asset_variant: false,
      is_phase: false,
      is_display: false });
    settingsStore.setPlcTags(temp);
  };
  const handleDelete = (index: number) => {
    const temp = settingsStore.read_tags;
    temp.splice(index, 1);
    settingsStore.setPlcTags(temp);
  };
  useEffect(() => {
    const temp = settingsStore.read_tags;
    temp[0].trigger_value = settingsStore.trigger_value;
    temp[0].trigger_type_name = 'timer';
    settingsStore.setPlcTags(temp);
  }, []);

  return (
    <EventHandlerContainer>
      <Typography variant="h3" sx={Subtitle} component="header">
        {locale.getString('settings.addressToRead')}
      </Typography>
      {settingsStore.read_tags.map((tag, i) => {
        return (
          <InnerContainer key={`plc-read-address-${i}`}>
            <FormControl sx={{minWidth: 'auto', height: 'auto'}}>
              <RadioGroup
                row
                aria-labelledby={locale.getString('settings.addressToRead')}
                name="adress-to-read"
              >
                {radioLabels.map((label, index) => {
                  return(
                    <FlexCol key={`${label}-${i}-${index}`} mr={0.5} sx={{alignItems: 'center'}}>
                      {i === 0 &&
                        <Typography variant="overline">{label}</Typography>
                      }
                      <Radio
                        checked={tag[radioKeys[index]]}
                        sx={{height: 45, width: 45}}
                        onChange={() => settingsStore.setPlcTagsWithKey(radioKeys[index], i, !tag[radioKeys[index]])}
                      />
                    </FlexCol>
                  );
                })}
              </RadioGroup>
            </FormControl>
            <FlexRow key={`session-detection-plctag-${i}`}>
              <FlexCol>
                {i === 0 && (
                  <Typography variant="overline">
                    {locale.getString('literals.name')}
                  </Typography>
                )}
                <TextField
                  size="small"
                  key={`read-tag-name-${i}`}
                  placeholder={locale.getString('settings.enterName')}
                  sx={FormStyle}
                  // onChange={testFunc}
                  onChange={(e: ChangeEvent<HTMLInputElement>) =>
                  {
                    textFieldOnChange(e.target.value, e.target.name, i);
                  }

                  }
                  name="name"
                />
              </FlexCol>
              <FlexCol sx={{alignItems: 'center'}}>
                {i === 0 &&
                  <Typography variant="overline">
                    {locale.getString('settings.display')}
                  </Typography>
                }
                <Checkbox
                  sx={{width: 45, height: 45}}
                  checked={tag[radioKeys[3]]}
                  onChange={() => settingsStore.setPlcTagsWithKey(radioKeys[3], i, !tag[radioKeys[3]])}
                  inputProps={{ 'aria-label': 'display' }}
                />
              </FlexCol>
              <Box style={{ marginRight: 16 }} />
              <FlexCol mr={1}>
                {i === 0 && (
                  <Typography variant="overline">
                    {locale.getString('literals.address')}
                  </Typography>
                )}
                <TextField
                  key={`read-tag-address-${i}`}
                  placeholder={locale.getString('settings.enterAddress')}
                  size="small"
                  sx={FormStyle}
                  type="number"
                  InputProps={{
                    startAdornment: (
                      <InputAdornment
                        position="start"
                        sx={{ marginBottom: '16px' }}
                      >
                          %MW
                      </InputAdornment>
                    ),
                  }}
                  onChange={(e: ChangeEvent<HTMLInputElement>) =>
                    textFieldOnChange(+e.target.value, e.target.name, i)
                  }
                  name="address"
                />
              </FlexCol>
              <FlexCol>
                {i === 0 && (
                  <Typography variant="overline">
                    {locale.getString('settings.count')}
                  </Typography>
                )}
                <TextField
                  key={`read-tag-count-${i}`}
                  sx={FormStyle}
                  placeholder="0x0001"
                  size="small"
                  type="number"
                  onChange={(e: ChangeEvent<HTMLInputElement>) =>
                    textFieldOnChange(+e.target.value, e.target.name, i)
                  }
                  name="count"
                />
              </FlexCol>
              <div onClick={() => handleDelete(i)}>
                {i !== 0 && <DeleteIcon sx={deleteIcon} />}
              </div>
            </FlexRow>
          </InnerContainer>
        );
      })}
      <Box sx={{ marginTop: 1 }} />
      <AddButtonContainer>
        <Button variant="text" style={addButton} onClick={addPlcTag}>
          <AddIcon style={{ marginRight: 16, color: '#003965' }} />
          {locale.getString('literals.add')}
        </Button>
      </AddButtonContainer>
    </EventHandlerContainer>
  );
};

export default observer(ReadAddress);
