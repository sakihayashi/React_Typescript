import {
  Box,
  Checkbox,
  FormControlLabel,
  FormGroup,
  InputAdornment,
  SelectChangeEvent,
  TextField,
  Typography,
} from '@mui/material';
import LocaleStore from '@otosense/locale';
import { observer } from 'mobx-react-lite';
import React, { ChangeEvent, useEffect } from 'react';
import { useRootContext } from '../../../../RootStore';
import AppState from '../../../../appState';
import SettingsStore from '../../../../settingsStore';
import {
  EventHandlerContainer,
  FlexCol,
  FlexRow,
  FormStyle,
  innerContainer,
  rowTitle,
  Subtitle,
} from './styles';
import { CenterBox } from '@otosense/components';

const WriteReady = () => {
  const root = useRootContext();
  const appState: AppState = root.appState;
  const locale: LocaleStore = appState.locale;
  const settingsStore: SettingsStore = root.settingsStore;

  const textFieldOnChange = (name: string, val: string | number) => {
    settingsStore.setPlcReadiness(name, val);
  };
  const selectOnChange = (e: SelectChangeEvent, fieldName: string) => {
    settingsStore.setPlcReadiness(fieldName, e.target.value);
  };
  const handleCheckBox = (e: ChangeEvent<HTMLInputElement>) => {
    settingsStore.setPlcReadiness(e.target.name, e.target.checked);
  };
  const operatorOpt = [
    locale.getString('literals.or'),
    locale.getString('literals.assign'),
  ];

  useEffect(() => {
    settingsStore.setPlcReadiness('trigger_value', settingsStore.trigger_value);
    settingsStore.setPlcReadiness('operation', '=');
  }, []);

  return (
    <EventHandlerContainer>
      <Typography variant="h3" component="header" sx={Subtitle}>
        {locale.getString('literals.ready')}
      </Typography>
      <Box sx={innerContainer}>
        <FlexRow>
          <Typography variant="h4" style={rowTitle}>
            {locale.getString('settings.readiness')}
          </Typography>
          <FlexCol mr={1}>
            <Typography variant="overline">
              {locale.getString('literals.address')}
            </Typography>
            <TextField
              variant="filled"
              placeholder={locale.getString('settings.enterAddress')}
              sx={FormStyle}
              size="small"
              type="number"
              InputProps={{
                startAdornment: (
                  <InputAdornment
                    position="start"
                    sx={{ marginBottom: '16px' }}
                  >
                    %MW
                  </InputAdornment>
                ),
              }}
              onChange={(e: ChangeEvent<HTMLInputElement>) => textFieldOnChange('address', +e.target.value)}
            />
          </FlexCol>
          <FlexCol mr={1}>
            <Typography variant="overline">
              {locale.getString('settings.operator')}
            </Typography>
            <CenterBox sx={{height: 45}}>
              <Typography variant="subtitle1">{locale.getString('literals.assign')}</Typography>
            </CenterBox>

          </FlexCol>
          <FlexCol>
            <Typography variant="overline">
              {locale.getString('literals.value')}
            </Typography>
            <TextField
              variant="filled"
              sx={FormStyle}
              placeholder="0x0001"
              type="number"
              size="small"
              onChange={(e: ChangeEvent<HTMLInputElement>) => textFieldOnChange('value', +e.target.value)}
            />
          </FlexCol>
        </FlexRow>
      </Box>
      <FlexRow>
        <FormGroup sx={{ marginLeft: '24px' }}>
          <FormControlLabel
            control={<Checkbox onChange={handleCheckBox} defaultChecked />}
            label={locale.getString('settings.resetValues')}
          />
        </FormGroup>
      </FlexRow>
    </EventHandlerContainer>
  );
};

export default observer(WriteReady);
