import {
  Box,
  FormControl,
  InputAdornment,
  MenuItem,
  Select,
  SelectChangeEvent,
  TextField,
  Typography,
} from '@mui/material';
import LocaleStore from '@otosense/locale';
import { observer } from 'mobx-react-lite';
import React, { ChangeEvent } from 'react';
import { useRootContext } from '../../../../RootStore';
import AppState from '../../../../appState';
import { FormBox } from '../../../../globalStyles/otoBox';
import SettingsStore from '../../../../settingsStore';
import {
  EventHandlerContainer,
  FlexCol,
  FlexRow,
  FormSelectStyle,
  FormStyle,
  innerContainer,
  rowTitle,
  Subtitle,
} from './styles';

const ReadSession = () => {
  const root = useRootContext();
  const appState: AppState = root.appState;
  const locale: LocaleStore = appState.locale;
  const settingsStore: SettingsStore = root.settingsStore;

  const operatorOpt = [
    locale.getString('settings.equalTo'),
    locale.getString('settings.moreThan'),
    locale.getString('settings.lessThan'),
    locale.getString('settings.notEqualTo'),
  ];
  const hiddenOperators: string[] = ['==', '>', '<', '<>'];
  const headers = [
    locale.getString('testing.start'),
    locale.getString('testing.stop'),
  ];
  const handleChanges = [
    settingsStore.setSessionBt,
    settingsStore.setSessionTt,
  ];

  const handleInterval = (val: number) => {
    settingsStore.setSessionBt('trigger_value', val);
    settingsStore.setSessionTt('trigger_value', val);
    settingsStore.setTriggerValue(val);
  };
  return (
    <EventHandlerContainer>
      <Typography variant="h3" sx={Subtitle}>
        {locale.getString('settings.sessionDetection')}
      </Typography>
      <Box sx={innerContainer}>
        {headers.map((header, i) => {
          return (
            <FlexRow
              key={`session-detection-${header}-${i}`}
              mb={i === 0 ? 1 : 0}
            >
              <Typography variant="h4" sx={rowTitle}>
                {header}
              </Typography>
              <FormBox mr={0.5}>
                {i === 0 &&
                <Typography variant="overline">
                  {locale.getString('literals.address')}
                </Typography>
                }
                <TextField
                  type="number"
                  placeholder={locale.getString('settings.enterAddress')}
                  InputProps={{
                    startAdornment: (
                      <InputAdornment
                        position="start"
                        sx={{ marginBottom: '16px' }}
                      >
                        %MW
                      </InputAdornment>
                    ),
                  }}
                  sx={FormStyle}
                  size="small"
                  onChange={(e: ChangeEvent<HTMLInputElement>) =>
                    handleChanges[i]('address', +e.target.value)
                  }
                />
              </FormBox>
              <FormBox mr={0.5}>
                {i === 0 &&
                <Typography variant="overline">
                  {locale.getString('settings.operator')}
                </Typography>
                }
                <FormControl variant="filled" size="xsmall">
                  <Select
                    sx={FormSelectStyle}
                    onChange={(e: SelectChangeEvent) =>
                      handleChanges[i]('operation', e.target.value)
                    }
                  >
                    {operatorOpt.map((opt, index) => {
                      return (
                        <MenuItem
                          key={`session-detect-operator-${opt}`}
                          value={hiddenOperators[index]}
                        >
                          {opt}
                        </MenuItem>
                      );
                    })}
                  </Select>
                </FormControl>
              </FormBox>
              <FlexCol>
                {i === 0 &&
                <Typography variant="overline">
                  {locale.getString('literals.value')}
                </Typography>
                }
                <TextField
                  size="small"
                  variant="filled"
                  sx={FormStyle}
                  placeholder="0x0001"
                  type="number"
                  onChange={(e: ChangeEvent<HTMLInputElement>) =>
                    handleChanges[i]('value', +e.target.value)
                  }
                />
              </FlexCol>
            </FlexRow>
          );
        })}
      </Box>
      <div style={{ marginTop: 24 }} />
      <Box sx={innerContainer}>
        <FlexRow>
          <Typography variant="h4" sx={rowTitle}>
            {locale.getString('settings.pullInterval')}
          </Typography>
          <FlexCol>
            <Typography variant="overline">
              {locale.getString('settings.duration')}
            </Typography>
            <TextField
              variant="filled"
              placeholder={locale.getString('settings.enterDuration')}
              size="small"
              type="number"
              sx={FormStyle}
              InputProps={{
                endAdornment: (
                  <InputAdornment position="end">
                    {locale.getString('settings.ms')}
                  </InputAdornment>
                ),
              }}
              onChange={(e: ChangeEvent<HTMLInputElement>) =>
                handleInterval(+e.target.value)
              }
            />
          </FlexCol>
          {/* <Typography variant="body1" style={unit}>
            {locale.getString('settings.ms')}
          </Typography> */}
        </FlexRow>
      </Box>
    </EventHandlerContainer>
  );
};

export default observer(ReadSession);
