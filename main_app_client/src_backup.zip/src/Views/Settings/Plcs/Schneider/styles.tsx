import { Box } from '@mui/material';
import { styled } from '@mui/material/styles';
import React, { CSSProperties } from 'react';

export const textCapitalize: React.CSSProperties = {
  textTransform: 'capitalize',
};

export const FlexRow = styled(Box)({
  display: 'flex',
  height: '100%',
  alignItems: 'center',
});

export const FlexCol = styled(Box)({
  display: 'flex',
  flexDirection: 'column',
});

export const FormStyle: React.CSSProperties = {
  // borderTopRightRadius: 0,
  // borderTopLeftRadius: 0,
  marginBottom: 0,
};
export const FormSelectStyle: React.CSSProperties = {
  borderTopRightRadius: 0,
  borderTopLeftRadius: 0,
  width: '150px',
};

export const rowTitle: React.CSSProperties = {
  marginTop: '22px',
  width: '95px',
  overflowWrap: 'break-word',
  textTransform: 'capitalize',
};
export const prefix: React.CSSProperties = {
  marginTop: '22px',
  marginBottom: 0,
  marginRight: 0.5,
};

export const Subtitle = {
  margin: 1,
  '::first-letter': {
    textTransform: 'uppercase',
  },
};

export const innerContainer: CSSProperties = {
  padding: '16px 24px',
  background: 'white',
  border: '1px solid lightgray',
  margin: '16px 24px',
};
export const InnerContainer = styled(Box)(({ theme }) => ({
  padding: 16,
  background: theme.palette.background.paper,
  border: `1px solid ${theme.palette.gray.light}`,
  margin: 16,
  display: 'flex',
  alignItems: 'center'
}));

export const deleteIcon: CSSProperties = {
  color: '#003965',
  marginTop: '2px',
  cursor: 'pointer',
};

export const addButton: CSSProperties = {
  height: '100%',
  width: '100%',
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  color: '#003965',
  margin: -16,
  padding: 16,
  textTransform: 'capitalize',
  textDecoration: 'none',
};

export const EventHandlerContainer = styled(Box)(({ theme }) => ({
  width: '100%',
  border: `1px solid ${theme.palette.gray.light}`,
  backgroundColor: theme.palette.background.default,
}));

export const unit = {
  marginTop: '22px',
  marginLeft: 8,
};

export const AddButtonContainer = styled(Box)(({ theme }) => ({
  padding: 0,
  height: 80,
  background: theme.palette.background.paper,
  border: `1px solid ${theme.palette.gray.light}`,
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  margin: 16,
}));
