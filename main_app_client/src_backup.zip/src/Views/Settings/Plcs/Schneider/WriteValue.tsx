import {
  Checkbox,
  FormControlLabel,
  FormGroup,
} from '@mui/material';
import LocaleStore from '@otosense/locale';
import { observer } from 'mobx-react-lite';
import React, { useState } from 'react';
import { useRootContext } from '../../../../RootStore';
import AppState from '../../../../appState';
import SettingsStore from '../../../../settingsStore';
import WriteQualityScore from './WriteQualityScore';
import WriteLearningMode from './WriteLearningMode';

const WriteValue = () => {
  const root = useRootContext();
  const appState: AppState = root.appState;
  const locale: LocaleStore = appState.locale;
  const settingsStore: SettingsStore = root.settingsStore;
  const [isLearning, setIsLearning] = useState<boolean>(false);
  const handleCheckbox = () => {
    if(isLearning){
      // iwill be false
      settingsStore.setPlcConfig('set_learning_mode', null);
    } else {
      // will be true
      const initialVal = {
        'name': 'LearningMode',
        'address': null,
        'operation': '=',
        'value': null,
      };
      settingsStore.setPlcConfig('set_learning_mode', initialVal);
    }
    setIsLearning(!isLearning);
  };
  return(
    <>
      <FormGroup>
        <FormControlLabel
          control={
            <Checkbox
              checked={isLearning}
              onChange={handleCheckbox}
            />
          }
          label={locale.getString('reviewSessions.learningMode')}
        />
      </FormGroup>
      {isLearning ?
        <WriteLearningMode />
        :
        <WriteQualityScore />
      }
    </>
  );
};

export default observer(WriteValue);