import {
  Box,
  Checkbox,
  FormControlLabel,
  FormGroup,
  InputAdornment,
  TextField,
  Typography,
} from '@mui/material';
import LocaleStore from '@otosense/locale';
import { action } from 'mobx';
import { observer } from 'mobx-react-lite';
import React, { ChangeEvent, useEffect } from 'react';
import { useRootContext } from '../../../../RootStore';
import AppState from '../../../../appState';
// import AssetTypeStore from '../../../../assetTypeStore';
import SettingsStore from '../../../../settingsStore';
import {
  EventHandlerContainer,
  FlexCol,
  FlexRow,
  FormStyle,
  innerContainer,
  rowTitle,
  Subtitle,
} from './styles';
import { CenterBox } from '@otosense/components';


const WriteQualityScore = () => {
  const root = useRootContext();
  const appState: AppState = root.appState;
  const locale: LocaleStore = appState.locale;
  // const assetTypeStore: AssetTypeStore = root.assetTypeStore;
  const settingsStore: SettingsStore = root.settingsStore;
  console.log('score jsx', settingsStore.read_tags);
  const handleCheckBox = action((e: ChangeEvent<HTMLInputElement>) => {
    settingsStore.quality_score.reset_on_session_start = e.target.checked;
  });
  // const operatorOpt = [
  //   locale.getString('literals.or'),
  //   locale.getString('literals.assign'),
  // ];
  const headers = [
    locale.getString('settings.qcReady'),
    locale.getString('settings.qcValue'),
  ];
  const onChanges = [settingsStore.setQsReady, settingsStore.setQsValue];
  // const values = [
  //   settingsStore.readiness,
  // ];
  useEffect(() => {
    settingsStore.setQsValue('operation', '=');
    settingsStore.setQsReady('operation', '=');
  });
  return (
    <>
      <EventHandlerContainer>
        <Typography variant="h3" sx={Subtitle}>
          {locale.getString('global.qualityScore')}
        </Typography>
        <Box sx={innerContainer}>
          {headers.map((header, i) => {
            return (
              <FlexRow key={`session-detection-${header}-${i}`} mb={1}>
                <Typography variant="h4" sx={rowTitle}>
                  {header}
                </Typography>
                <FlexCol mr={1}>
                  <Typography variant="overline">
                    {locale.getString('literals.address')}
                  </Typography>
                  <TextField
                    size="small"
                    placeholder={locale.getString('settings.enterAddress')}
                    sx={FormStyle}
                    type="number"
                    onChange={(e: ChangeEvent<HTMLTextAreaElement>) =>
                      onChanges[i]('address', +e.target.value)
                    }
                    InputProps={{
                      startAdornment: (
                        <InputAdornment
                          position="start"
                          sx={{ marginBottom: '16px' }}
                        >
                        %MW
                        </InputAdornment>
                      ),
                    }}
                  />
                </FlexCol>
                {i === 0 && (
                  <>
                    <FlexCol mr={1}>
                      <Typography variant="overline">
                        {locale.getString('settings.operator')}
                      </Typography>
                      <CenterBox sx={{height: 45}}>
                        <Typography variant="subtitle1">{locale.getString('literals.assign')}</Typography>
                      </CenterBox>
                    </FlexCol>
                    <FlexCol>
                      <Typography variant="overline">
                        {locale.getString('literals.value')}
                      </Typography>
                      <TextField
                        id={`session-${header}-val-${i}`}
                        size="small"
                        style={FormStyle}
                        placeholder="0x0001"
                        type="number"
                        onChange={(e: ChangeEvent<HTMLTextAreaElement>) =>
                          onChanges[i]('value', +e.target.value)
                        }
                      />
                    </FlexCol>
                  </>
                )}
              </FlexRow>
            );
          })}
          <FlexRow>
            <Box />
            <FormGroup>
              <FormControlLabel
                control={
                  <Checkbox
                    id="qs-reset-values"
                    onChange={handleCheckBox}
                    defaultChecked
                  />
                }
                label={locale.getString('settings.resetValues')}
              />
            </FormGroup>
          </FlexRow>
        </Box>
      </EventHandlerContainer>
    </>
  );
};

export default observer(WriteQualityScore);
