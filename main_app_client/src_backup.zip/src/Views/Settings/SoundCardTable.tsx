// import { toJS } from 'mobx';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  TextField,
} from '@mui/material';
import LocaleStore from '@otosense/locale';
import { observer } from 'mobx-react-lite';
import React from 'react';
import { useRootContext } from '../../RootStore';
import AppState from '../../appState';
import AssetTypeStore from '../../assetTypeStore';

const SoundCardTable = () => {
  const root = useRootContext();
  const settingsStore = root.settingsStore;
  const appState: AppState = root.appState;
  const locale: LocaleStore = appState.locale;
  const assetTypeStore: AssetTypeStore = root.assetTypeStore;

  const handleChange: (
    fieldName: string
  ) => (e: React.ChangeEvent<HTMLInputElement>) => void =
    (fieldName: string) => (e: React.ChangeEvent<HTMLInputElement>) => {
      assetTypeStore.setConfig(fieldName, e.target.value);
    };

  return (
    <Table>
      <TableHead>
        <TableRow>
          {settingsStore.selectedReader &&
            settingsStore.selectedReader.fields.map((field, index) => {
              if (field.is_per_device_channel) {
                return (
                  <TableCell key={`field-name-${field.name}-${index}`}>
                    {locale.getString(`settings.${field.name}`)}
                  </TableCell>
                );
              }
            })}
        </TableRow>
      </TableHead>
      <TableBody>
        <TableRow>
          {settingsStore.selectedReader &&
            settingsStore.selectedReader.fields.map((field, index) => {
              if (field.is_per_device_channel) {
                if (field.type === 'text input') {
                  return (
                    <TableCell key={`${field.name}-${index}`}>
                      <TextField
                        aria-describedby={`${field.type}-input`}
                        placeholder={locale.getString(`settings.${field.name}`)}
                        value={assetTypeStore.config[field.name] || ''}
                        onChange={handleChange(field.name)}
                      />
                    </TableCell>
                  );
                }
              }
            })}
        </TableRow>
      </TableBody>
    </Table>
  );
};

export default observer(SoundCardTable);
