import {
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  ListItemButton,
  ListItemText,
  TextField,
  Typography,
} from '@mui/material';
import LocaleStore from '@otosense/locale';
// import { toJS } from 'mobx';
import { observer } from 'mobx-react-lite';
import React, { useState } from 'react';
import { useRootContext } from '../../RootStore';
import AppState from '../../appState';
import AssetTypeStore, { AssetType, QCChannel } from '../../assetTypeStore';
import { FlexBox, FlexSpaceBet } from '../../globalStyles/otoBox';
import SettingsStore from '../../settingsStore';
import { PromiseFunction } from '../../Utility/types';
import { ViewAssetList } from './styles';

interface IProps {
  onClose: VoidFunction;
}

const ViewAssetType = (props: IProps) => {
  const { onClose } = props;
  const root = useRootContext();
  const appState: AppState = root.appState;
  const settingsStore: SettingsStore = root.settingsStore;
  const assetTypeStore: AssetTypeStore = root.assetTypeStore;
  const locale: LocaleStore = appState.locale;
  const selectedAssetType: AssetType = assetTypeStore.selectedAssetType;
  const [newVariantName, setNewVariantName] = useState<string>('');
  const [newChannelName, setNewChannelName] = useState<string>('');
  const [visible, setVisible] = useState<boolean>(true);
  const handleVariantNameChange: (e: any) => void = (e) => {
    setNewVariantName(e.target.value);
  };
  const handleChannelNameChange: (e: any) => void = (e) => {
    setNewChannelName(e.target.value);
  };
  const cancelAndClose = () => {
    // assetTypeStore.setIsAllSelectedFalse();
    settingsStore.resetDeviceSettings();
    onClose();
  };

  const createNewVariant: PromiseFunction = () => {
    const res = assetTypeStore.createNewVariant(newVariantName);
    if (res) {
      setNewVariantName('');
    }
    return res;
  };
  const createNewChannel: PromiseFunction = () => {
    const res = assetTypeStore.createNewChannel(newChannelName);
    if (res) {
      setNewChannelName('');
    }
    return res;
  };

  let variantName: string = '';
  if (assetTypeStore.selectedVariant) {
    variantName = `variant ${assetTypeStore.selectedVariant._id}`;
  }
  if (!selectedAssetType) {
    return (
      <Dialog open={true} onClose={onClose} aria-labelledby="dialog-title" />
    );
  }
  const goToNextScreen = () => {
    // assetTypeStore.setIsAllSelected();
    settingsStore.pipelineConfigOptions();
    settingsStore.nextEditConfig();
  };

  return (
    <Dialog
      id="dialog-search"
      open={visible}
      onClose={() => setVisible(false)}
      aria-labelledby="dialog-title"
      maxWidth="md"
    >
      <DialogTitle id="dialog-title-view-asset">
        <Typography variant="h2" component="header">
          {locale.getString('settings.selectVariantPipeline')}
        </Typography>
        <Typography variant="subtitle1">
          {locale.getString('testing.assetType')} :{' '}
          <b>{selectedAssetType.name ? selectedAssetType.name : ''}</b>
        </Typography>
      </DialogTitle>
      <DialogContent>
        <FlexSpaceBet>
          <Box sx={{ width: 250 }} mr={1}>
            <Typography
              variant="body1"
              mb={0.5}
              sx={{ minHeight: 36 }}
              component="header"
            >
              {locale.getString('settings.variants')}:
              <b>
                {assetTypeStore.selectedVariant &&
                  assetTypeStore.selectedVariant._id}
              </b>
            </Typography>
            <Box sx={{ width: '100%' }} pb={1}>
              <ViewAssetList>
                {assetTypeStore.selectedAssetType.variants &&
                  assetTypeStore.selectedAssetType.variants.map(
                    (variant, index) => (
                      <ListItemButton
                        selected={
                          assetTypeStore.selectedVariant._id === variant._id
                        }
                        key={`variant-${index}`}
                        onClick={() => assetTypeStore.selectVariant(variant)}
                      >
                        <ListItemText primary={variant._id} />
                      </ListItemButton>
                    )
                  )}
              </ViewAssetList>
            </Box>
            <FlexBox>
              <TextField
                variant="outlined"
                label={locale.getString('settings.addNewVariant')}
                onChange={handleVariantNameChange}
                value={newVariantName}
              />
              <Button disabled={!newVariantName} onClick={createNewVariant}>
                {locale.getString('literals.save')}
              </Button>
            </FlexBox>
          </Box>
          <Box sx={{ width: 250 }}>
            <Typography
              variant="body1"
              mb={0.5}
              sx={{ minHeight: 36 }}
              component="header"
            >
              {locale.getFormattedString('settings.channelsForVariant', {
                variantName: ': ',
              })}
              <b>{variantName}</b>
            </Typography>
            <Box sx={{ width: '100%', pb: 1 }}>
              <ViewAssetList>
                {assetTypeStore.availableChannels.map((channel: QCChannel) => {
                  return (
                    <ListItemButton
                      key={`channel-${channel._id}`}
                      selected={
                        assetTypeStore.selectedChannel.name === channel.name
                      }
                      onClick={() => assetTypeStore.setChannel(channel)}
                    >
                      <ListItemText primary={channel.name + ''} />
                    </ListItemButton>
                  );
                })}
              </ViewAssetList>
            </Box>
            {!!assetTypeStore.selectedVariant && (
              <FlexBox>
                <TextField
                  variant="outlined"
                  label={locale.getString('settings.addNewChannel')}
                  onChange={handleChannelNameChange}
                  value={newChannelName}
                />
                <Button disabled={!newChannelName} onClick={createNewChannel}>
                  {locale.getString('literals.save')}
                </Button>
              </FlexBox>
            )}
          </Box>
        </FlexSpaceBet>
      </DialogContent>
      <DialogActions>
        <Button color="cancel" onClick={cancelAndClose}>
          {locale.getString('literals.close')}
        </Button>
        <Button
          onClick={goToNextScreen}
          disabled={
            !(assetTypeStore.selectedChannel && assetTypeStore.selectedVariant)
          }
        >
          {locale.getString('util.next')}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default observer(ViewAssetType);
