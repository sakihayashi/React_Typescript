import MoreVertIcon from '@mui/icons-material/MoreVert';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import LocaleStore from '@otosense/locale';
import { observer } from 'mobx-react-lite';
import React, { useEffect, useState } from 'react';
import { useRootContext } from '../../RootStore';
import AppState from '../../appState';
import { FlexBox } from '../../globalStyles/otoBox';
import { selectedTabStyle, tabStyle } from '../../globalStyles/tabs';
import SettingsStore from '../../settingsStore';
import { RenderFunction } from '../../Utility/types';
import AppSettings from './AppSettings';
import AssetTypes from './AssetTypes';
import { MainContainer } from './styles';

const subTabs: string[] = ['testConfiguration', 'settings'];

const Settings = () => {
  const root = useRootContext();
  const appState: AppState = root.appState;
  const locale: LocaleStore = appState.locale;
  const settingsStore: SettingsStore = root.settingsStore;
  const [selectedSubTab, setSelectedSubTab] = useState<string>(subTabs[0]);

  useEffect(() => {
    settingsStore.loadPipelineAndTestStatus();
  }, []);

  // const renderLastSync: RenderFunction = () => {
  //     const { last_update: lastSync } = appState.syncStatus;
  //     const dateString = appState.formatTimestamp(lastSync);
  //     return (
  //         <div>
  //             <a>{locale.getString('settings.lastSync')} {dateString} </a>
  //         </div>
  //     );
  // };

  // const renderNextSync: RenderFunction = () => {
  //     const { next_update: nextSync } = appState.syncStatus;
  //     const dateString = appState.formatTimestamp(nextSync);
  //     return (
  //         <div>
  //             <a>{locale.getString('settings.nextSync')} {dateString} </a>
  //         </div>
  //     );
  // };

  // const renderLatestPipelineInfo: RenderFunction = () => {
  //     if (settingsStore.pipelineInfo) {
  //         const pipelineName = locale.getString('settings.pipelineName');
  //         const name = settingsStore.pipelineInfo.pipeline_name || settingsStore.pipelineInfo.pipeline_id;
  //         const updatedOn = locale.getString('settings.updatedOn');
  //         const date = appState.formatTimestamp(settingsStore.pipelineInfo.modified_time);
  //         return (<div>{`${pipelineName} ${name} ${updatedOn} ${date}`}</div>);
  //     }
  // };

  const renderTabs: RenderFunction = () => {
    const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
    const open = Boolean(anchorEl);
    const handleClick = (event: React.MouseEvent<HTMLElement>) => {
      setAnchorEl(event.currentTarget);
    };
    const handleClose = () => {
      setAnchorEl(null);
    };

    const tabs: JSX.Element[] = subTabs.map((v) => {
      return (
        <Button
          key={`tab-${v}`}
          variant="text"
          sx={v === selectedSubTab ? selectedTabStyle : tabStyle}
          onClick={() => setSelectedSubTab(v)}
        >
          {locale.getString(`settings.${v}`)}
        </Button>
      );
    });

    const content = () => {
      switch (selectedSubTab) {
      case 'testConfiguration':
        return <AssetTypes />;
      case 'settings':
        return <AppSettings />;
      default:
        return <AssetTypes />;
      }
    };

    return (
      <>
        <FlexBox component="nav" sx={{ justifyContent: 'space-between' }}>
          <FlexBox>{tabs}</FlexBox>
          <Box onClick={handleClick} sx={{ mt: 1 }}>
            <MoreVertIcon />
          </Box>
          <Menu
            id="demo-positioned-menu"
            aria-labelledby="demo-positioned-button"
            anchorEl={anchorEl}
            open={open}
            onClose={handleClose}
            anchorOrigin={{
              vertical: 'top',
              horizontal: 'right',
            }}
            transformOrigin={{
              vertical: 'top',
              horizontal: 'left',
            }}
          >
            <MenuItem onClick={appState.launchDppBuilder}>
              {locale.getString('settings.openDppApp')}
            </MenuItem>
          </Menu>
        </FlexBox>
        {content()}
      </>
    );
  };

  // const isLoginModeOnline = appState.isLoginModeOnline;
  return (
    <MainContainer>
      {/* <div className="oto-settings__syncStatus">
                <div className="oto-settings__syncStatus--column md-text-right">
                    {renderLastSync()}
                    {renderNextSync()}
                    {renderLatestPipelineInfo()}
                </div>
                <Button
                    disabled={!isLoginModeOnline}
                    buttonType="icon"
                    onClick={appState.sync}
                    className={isLoginModeOnline && 'oto-settings__syncStatus__icon'}
                    themeType="flat"
                >
                    <FontIcon>cached</FontIcon>
                </Button>
            </div> */}
      {renderTabs()}
    </MainContainer>
  );
};

export default observer(Settings);
