// import Dialog from '@mui/material/Dialog';
import {
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControl,
  FormControlLabel,
  MenuItem,
  Radio,
  RadioGroup,
  Select,
  SelectChangeEvent,
  Typography,
} from '@mui/material';
import Button from '@mui/material/Button';
import LocaleStore from '@otosense/locale';
// import { toJS } from 'mobx';
import { observer } from 'mobx-react-lite';
import React from 'react';
import { useRootContext } from '../../RootStore';
import AppState from '../../appState';
import { FlexBox } from '../../globalStyles/otoBox';
import SettingsStore from '../../settingsStore';
import AssetComb from '../components/AssetComb';

interface IProps {
  onClose: VoidFunction;
  // visible: boolean;
  // openNextDialog: VoidFunction;
}

const SelectEventHandlers = (props: IProps) => {
  const { onClose } = props;
  const root = useRootContext();
  const appState: AppState = root.appState;
  const locale: LocaleStore = appState.locale;
  const settingsStore: SettingsStore = root.settingsStore;
  const ipAddress_port = [
    {name: 'ip_address', type: 'text', inputProps: {maxLength: 15, pattern: '^([0-9a-fA-F]{4}:){7}[0-9a-fA-F]{4}$'}, placeholder: 'xxx.xxx.xxx.xxx' },
    {name: 'port_number', type: 'number', inputProps: { step: 1, maxLength: 6}}
  ];

  const triggerTypes = [
    locale.getString('settings.timer'),
    locale.getString('settings.usbButton'),
    locale.getString('settings.plc'),
  ];
  const triggerTypeEn = ['timer', 'button', 'plc'];
  const plcOptions = [locale.getString('settings.schneider')];
  settingsStore.setSelectedPlcType(plcOptions[0]);
  const cancelAndClose = () => {
    onClose();
    settingsStore.resetDeviceSettings();
  };
  const goToNext = () => {
    settingsStore.nextEditConfig();
  };

  return (
    <Dialog open={true} onClose={onClose}>
      <DialogTitle>
        <Typography variant="h2" component="header" mb={1}>
          {locale.getString('settings.selectEventHandler')}
        </Typography>
        <AssetComb />
      </DialogTitle>

      <DialogContent>
        <FormControl sx={{ height: 'auto', width: 'auto' }}>
          <RadioGroup
            aria-label="event handlers"
            defaultValue={triggerTypes[0]}
          >
            {triggerTypes.map((type, i) => {
              return (
                <FlexBox key={`event-handler-${type}`}>
                  <FormControlLabel
                    sx={{
                      '& .MuiTypography-root:first-letter': {
                        textTransform: 'uppercase',
                      },
                    }}
                    value={triggerTypeEn[i]}
                    control={
                      <Radio
                        name={triggerTypeEn[i]}
                        onChange={settingsStore.setCurrentTriggerType}
                        checked={
                          settingsStore.currentTriggerType === triggerTypeEn[i]
                        }
                      />
                    }
                    label={type}
                  />
                  {triggerTypeEn[i] === 'plc' && (
                    <FormControl size="small" sx={{ marginLeft: 1 }}>
                      <Select
                        labelId="demo-simple-select-label"
                        id="demo-simple-select"
                        value={settingsStore.selectedPlcType}
                        label="Age"
                        onChange={(e: SelectChangeEvent) =>
                          settingsStore.setSelectedPlcType(e.target.value)
                        }
                        size="small"
                      >
                        {plcOptions.map((opt) => {
                          return (
                            <MenuItem key={opt} value={opt}>
                              {opt}
                            </MenuItem>
                          );
                        })}
                      </Select>
                    </FormControl>
                  )}

                </FlexBox>
              );
            })}
          </RadioGroup>
        </FormControl>
      </DialogContent>
      <DialogActions>
        <Button color="cancel" onClick={cancelAndClose}>
          {locale.getString('literals.close')}
        </Button>
        <Button
          onClick={goToNext}
          // disabled={settingsStore.assignedTriggers.length ? false : true}
        >
          {locale.getString('util.next')}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default observer(SelectEventHandlers);
