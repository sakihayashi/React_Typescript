import { Typography } from '@mui/material';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Checkbox from '@mui/material/Checkbox';
import FormControl from '@mui/material/FormControl';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormGroup from '@mui/material/FormGroup';
import MenuItem from '@mui/material/MenuItem';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import LocaleStore from '@otosense/locale';
import { observer } from 'mobx-react-lite';
import React from 'react';
import { useRootContext } from '../../RootStore';
import AppState from '../../appState';
import { FlexBox } from '../../globalStyles/otoBox';
import SettingsStore from '../../settingsStore';
import { RenderFunction } from '../../Utility/types';

const UploadOptions = () => {
  const root = useRootContext();
  const appState: AppState = root.appState;
  const locale: LocaleStore = appState.locale;
  const settingsStore: SettingsStore = root.settingsStore;
  const dataWithAssetsLabel: string = locale.getString(
    'settings.dataWithAssets',
    '{}'
  );
  let dataWithAssetsSplitLabel: string[] = dataWithAssetsLabel.split('{}');
  if (dataWithAssetsSplitLabel.length < 2) {
    dataWithAssetsSplitLabel = ['', ''];
  }
  const renderQualityScoreDropdown: RenderFunction = () => {
    const options = [];
    for (let i = 0; i <= 10; i++) {
      options.push('' + i);
    }
    return (
      <FormControl size="xsmall">
        <Select
          value={'' + appState.config.upload_min_quality_score.qualityScore}
          onChange={(e: SelectChangeEvent) =>
            settingsStore.setSettingsConfig(
              e.target.value,
              'upload_min_quality_score.qualityScore'
            )
          }
        >
          {options.map((option, i) => {
            return (
              <MenuItem key={`score-opt-${option}-${i}`} value={option}>
                {option}
              </MenuItem>
            );
          })}
        </Select>
      </FormControl>
    );
  };
  const renderAssetCountDropdown: RenderFunction = () => {
    const options = [];
    for (let i = 10; i < 100; i = i + 10) {
      options.push(i.toString());
    }
    return (
      <FormControl size="xsmall">
        <Select
          value={'' + appState.config.upload_min_asset_count.count}
          onChange={(e: SelectChangeEvent) =>
            settingsStore.setSettingsConfig(
              +e.target.value,
              'upload_min_asset_count.count'
            )
          }
        >
          {options.map((option, i) => {
            return (
              <MenuItem key={`upload-count-${option}`} value={option}>
                {option}
              </MenuItem>
            );
          })}
        </Select>
      </FormControl>
    );
  };
  return (
    <>
      <FormGroup>
        <FormControlLabel
          control={
            <Checkbox
              onChange={settingsStore.setUploadAllData}
              checked={appState.config.upload_all_data}
            />
          }
          label={locale.getString('settings.allData')}
        />
      </FormGroup>
      <FlexBox>
        <FormGroup>
          <FormControlLabel
            control={
              <Checkbox
                onChange={settingsStore.setUploadMinQualityScore}
                checked={appState.config.upload_min_quality_score.toUpload}
              />
            }
            label={locale.getString('settings.qualityScoreGreaterThan')}
          />
        </FormGroup>
        {renderQualityScoreDropdown()}
      </FlexBox>
      <FlexBox alignItems="center" m="8px 0">
        <FormGroup>
          <FormControlLabel
            control={
              <Checkbox
                id="dataAssets"
                checked={appState.config.upload_min_asset_count.toUpload}
                onChange={settingsStore.setUploadMinAssetCount}
              />
            }
            label={dataWithAssetsSplitLabel[0]}
          />
        </FormGroup>
        {renderAssetCountDropdown()}
        <Typography variant="body1" component="span" ml={0.5}>
          {dataWithAssetsSplitLabel[1]}
        </Typography>
      </FlexBox>
      <FlexBox>
        <FormGroup>
          <FormControlLabel
            control={
              <Checkbox
                checked={appState.config.manual_upload}
                onChange={settingsStore.setManualUpload}
              />
            }
            label={locale.getString('settings.manualData')}
          />
        </FormGroup>
      </FlexBox>
      <Box textAlign="right">
        <Button onClick={settingsStore.saveSettings}>Save</Button>
      </Box>
    </>
  );
};

export default observer(UploadOptions);
