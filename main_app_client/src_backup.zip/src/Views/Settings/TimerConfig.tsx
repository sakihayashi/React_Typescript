import InfoIcon from '@mui/icons-material/Info';
import { TextField, Typography } from '@mui/material';
import LocaleStore from '@otosense/locale';
import { observer } from 'mobx-react-lite';
import React, { ChangeEvent } from 'react';
import { useRootContext } from '../../RootStore';
import AppState from '../../appState';
import { FlexBox, FormBox } from '../../globalStyles/otoBox';
import SettingsStore from '../../settingsStore';
import { InfoIconStyle, TimerBox, UnitBoxEventConfig } from './styles';

const TimerConfig = () => {
  const root = useRootContext();
  const appState: AppState = root.appState;
  const locale: LocaleStore = appState.locale;
  const settingsStore: SettingsStore = root.settingsStore;
  const values = [
    settingsStore.duration,
    settingsStore.interval,
    settingsStore.maxSessions,
  ];
  const headers = [
    locale.getString('settings.duration'),
    locale.getString('settings.interval'),
    locale.getString('settings.maxSessions'),
  ];
  return (
    <TimerBox sx={{ width: 650 }}>
      {headers.map((header, index) => {
        let unitLabel: string;
        if (index < 2) {
          unitLabel = locale.getString('settings.seconds');
        } else {
          unitLabel = locale.getString('settings.sessions');
        }
        return (
          <FlexBox
            mb={2}
            mr={4}
            sx={{ flex: '1' }}
            key={`timer-config-setting-${header}-${index}`}
          >
            <FormBox>
              <Typography variant="overline">{header}</Typography>
              <FlexBox>
                <TextField
                  type="number"
                  size="small"
                  sx={{ width: 250 }}
                  value={values[index].toString()}
                  name={header}
                  onChange={(e: ChangeEvent<HTMLInputElement>) =>
                    settingsStore.setTimerValues(e, index)
                  }
                />
                <UnitBoxEventConfig>
                  <Typography variant="body1">{unitLabel}</Typography>
                </UnitBoxEventConfig>
              </FlexBox>
              {header === locale.getString('settings.maxSessions') && (
                <FlexBox>
                  <InfoIcon sx={InfoIconStyle} />
                  <Typography variant="caption">
                    {locale.getString('settings.0IsUnlimited')}
                  </Typography>
                </FlexBox>
              )}
            </FormBox>
          </FlexBox>
        );
      })}
    </TimerBox>
  );
};

export default observer(TimerConfig);
