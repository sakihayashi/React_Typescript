import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Box,
  Button,
  Checkbox,
  FormControlLabel,
  FormGroup,
  Typography,
} from '@mui/material';
import LocaleStore from '@otosense/locale';
import { observer } from 'mobx-react-lite';
import React from 'react';
import { useRootContext } from '../../RootStore';
import AppState from '../../appState';
import SettingsStore from '../../settingsStore';
import { RenderFunction } from '../../Utility/types';
import UploadOptions from './UploadOptions';

const AppSettings = () => {
  const root = useRootContext();
  const appState: AppState = root.appState;
  const locale: LocaleStore = appState.locale;
  const settingsStore: SettingsStore = root.settingsStore;

  const headers = [
    locale.getString('settings.automateUpload'),
    locale.getString('settings.automateDownload'),
    locale.getString('settings.automateUpdate'),
  ];

  const titles = [
    locale.getString('settings.transferToServer'),
    locale.getString('settings.downloadNewModels'),
    locale.getString('settings.softwareUpdates'),
  ];
  const renderNewModelOpt: RenderFunction = () => {
    return (
      <>
        <FormGroup>
          <FormControlLabel
            control={
              <Checkbox
                checked={appState.config.download_new_models}
                onChange={(e) =>
                  settingsStore.setSettingsConfig(
                    e.target.checked,
                    'download_new_models'
                  )
                }
              />
            }
            label={locale.getString('settings.allowModelDownloads')}
          />
        </FormGroup>
        <Box textAlign="right">
          <Button onClick={settingsStore.saveSettings}>Save</Button>
        </Box>
      </>
    );
  };
  const renderSoftwareUpdates: RenderFunction = () => {
    return (
      <>
        <FormGroup>
          <FormControlLabel
            control={
              <Checkbox
                checked={appState.config.automatic_software_updates}
                onChange={(e) =>
                  settingsStore.setSettingsConfig(
                    e.target.checked,
                    'automatic_software_updates'
                  )
                }
              />
            }
            label={locale.getString('settings.allowAutomaticUpdates')}
          />
        </FormGroup>
        <Box textAlign="right">
          <Button onClick= { settingsStore.saveOTASettings}>Save</Button>
        </Box>
      </>
    );
  };
  const renderUploadOpts: RenderFunction = () => {
    return <UploadOptions />;
  };
  const contents = [
    renderUploadOpts(),
    renderNewModelOpt(),
    renderSoftwareUpdates(),
  ];
  return (
    <main>
      <hr />
      {headers.map((header, i) => {
        return (
          <Accordion key={`settings-${header}`} disableGutters={true}>
            <AccordionSummary
              expandIcon={<ExpandMoreIcon />}
              aria-controls="panel1bh-content"
              id={`settings-header-${header}`}
            >
              <Typography variant="subtitle1" m={0}>
                {header}
              </Typography>
            </AccordionSummary>
            <AccordionDetails>
              {titles[i]}
              {contents[i]}
            </AccordionDetails>
          </Accordion>
        );
      })}
    </main>
  );
};

export default observer(AppSettings);
