import Checkbox from '@mui/material/Checkbox';
import FormControl from '@mui/material/FormControl';
import MenuItem from '@mui/material/MenuItem';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import TextField from '@mui/material/TextField';
import LocaleStore from '@otosense/locale';
import { toJS } from 'mobx';
import { observer } from 'mobx-react-lite';
import React, { useEffect, useState } from 'react';
import { Fields } from '../../api';
import { useRootContext } from '../../RootStore';
import AppState from '../../appState';
import AssetTypeStore from '../../assetTypeStore';
import SettingsStore from '../../settingsStore';

const WebDaqTable = () => {
  const root = useRootContext();
  const appState: AppState = root.appState;
  const locale: LocaleStore = appState.locale;
  const settingsStore: SettingsStore = root.settingsStore;
  // const {selectedReader, savedReaderName, selectedReaderName} = settingsStore;
  // const {setFieldOptions} = assetTypeStore;
  // const {setConfigs} = assetTypeStore;
  const assetTypeStore: AssetTypeStore = root.assetTypeStore;
  const [couplingIndex, setCouplingIndex] = useState<number>(null);
  const [modeIndex, setModeIndex] = useState<number>(null);

  const handleSelect = (index: number, fieldName: string, value: string) => {
    const tempArr = [...assetTypeStore.configs];
    tempArr[index][fieldName] = value;
    assetTypeStore.setConfigs(tempArr);
  };

  const handleChange: (
    fieldName: string,
    index: number
  ) => (e: React.ChangeEvent<HTMLInputElement>) => void =
    (fieldName: string, index: number) =>
      (e: React.ChangeEvent<HTMLInputElement>) => {
        const tempArr = [...assetTypeStore.configs];
        tempArr[index][fieldName] = e.target.value;
        assetTypeStore.setConfigs(tempArr);
      };

  const handleToggle: (field: Fields, index: number) => () => void =
    (field: Fields, index: number) => () => {
      const cloneConfig = [...assetTypeStore.configs];
      cloneConfig[index][field.name] = !cloneConfig[index][field.name];
      const cloneOptions = [...assetTypeStore.fieldOptions];
      const couplingObj: Fields = settingsStore.selectedReader.fields.find(
        (obj) => obj.name === 'coupling'
      );
      const modeObj: Fields = settingsStore.selectedReader.fields.find(
        (obj) => obj.name === 'mode'
      );
      if (assetTypeStore.configs[index][field.name]) {
        if (!!couplingObj.if_iepe) {
          cloneConfig[index].coupling = couplingObj.if_iepe;
        }
        if (!!modeObj.if_iepe) {
          cloneConfig[index].mode = modeObj.if_iepe;
        }
        const newArr = cloneOptions.map((innerArr: any, i) => {
          if (i === index) {
            return innerArr.map((arr: any, j: number) => {
              if (j === couplingIndex) {
                if (couplingObj.if_iepe) {
                  return [couplingObj.if_iepe];
                } else {
                  return arr;
                }
              } else if (j === modeIndex) {
                if (modeObj.if_iepe) {
                  return [modeObj.if_iepe];
                } else {
                  return arr;
                }
              } else {
                return arr;
              }
            });
          } else {
            return innerArr;
          }
        });
        assetTypeStore.setFieldOptions(newArr);
      } else {
        cloneConfig[index].coupling = couplingObj.values[0];
        cloneConfig[index].mode = modeObj.values[0];
        const newArr = cloneOptions.map((innerArr: any, i) => {
          if (i === index) {
            return innerArr.map((arr: any, j) => {
              if (j === couplingIndex) {
                return couplingObj.values;
              } else if (j === modeIndex) {
                return modeObj.values;
              } else {
                return arr;
              }
            });
          } else {
            return innerArr;
          }
        });
        assetTypeStore.setFieldOptions(newArr);
      }
      assetTypeStore.setConfigs(cloneConfig);
    };
  const renderRow = (
    field: any,
    index: number,
    channelId: string,
    childIndex: number
  ) => {
    switch (field.type) {
    case 'multiple choice':
      return (
        <TableCell key={`select-${field.name}-${childIndex}-${channelId}`}>
          <FormControl size="small">
            <Select
              value={
                assetTypeStore.configs && assetTypeStore.configs[index]
                  ? assetTypeStore.configs[index][field.name]
                  : ''
              }
              onChange={(e: SelectChangeEvent) =>
                handleSelect(index, field.name, e.target.value)
              }
              variant="filled"
              sx={{ width: 132, height: 45, padding: '5px 16px' }}
            >
              {assetTypeStore.fieldOptions &&
                assetTypeStore.fieldOptions[index] &&
                assetTypeStore.fieldOptions[index][childIndex].map(
                  (option, i) => {
                    return (
                      <MenuItem key={`${option}-${i}`} value={option}>
                        {option}
                      </MenuItem>
                    );
                  }
                )}
            </Select>
          </FormControl>
        </TableCell>
      );
    case 'text input':
      return (
        <TableCell key={`textinput-${field.name}-${childIndex}-${channelId}`}>
          <TextField
            id={`${index}-${field.name}`}
            aria-describedby={`${field.type}-input-${channelId}`}
            required
            variant="filled"
            placeholder={
              `${locale.getString('settings.enter')} ${locale.getString(`settings.${field.name}`)}`
            }
            sx={{ margin: 0 }}
            size="medium"
            value={
              assetTypeStore.configs && assetTypeStore.configs[index]
                ? assetTypeStore.configs[index][field.name] + ''
                : ''
            }
            name={field.name}
            onChange={(e) => {
              const temp = [...assetTypeStore.configs];
              temp[index][field.name] = e.target.value;
              assetTypeStore.setConfigs(temp);
            }}
          />
        </TableCell>
      );
    case 'boolean':
      return (
        <TableCell key={`boolean-${field.name}-${childIndex}-${channelId}`}>
          <Checkbox
            key={`checkbox-${field.name}-${childIndex}-${channelId}`}
            id={`checkbox-${field.name}-${childIndex}-${channelId}`}
            name={field.name}
            onChange={handleToggle(field, index)}
            checked={
              assetTypeStore.configs && assetTypeStore.configs[index]
                ? assetTypeStore.configs[index][field.name]
                : false
            }
          />
        </TableCell>
      );
    case 'range':
      return (
        <TableCell key={`${field.name}-${childIndex}-${channelId}`}>
          <TextField
            aria-describedby={`${field.name}-input`}
            type="number"
            value={assetTypeStore.configs[index][field.name] + '' || ''}
            placeholder={locale.getString(`settings.${field.name}`)}
            onChange={handleChange(field.name, index)}
            size="small"
            required
          />
        </TableCell>
      );
    default:
      return;
    }
  };
  const getData = () => {
    const cloneReader = { ...settingsStore.selectedReader };
    const configData = cloneReader.channel_ids.map((id: string) => {
      const configObj: Fields = {};
      const arr = cloneReader.fields.map((field) => {
        if (field.is_per_device_channel) {
          configObj[field.name] =
            field.type === 'multiple choice'
              ? field.values[0]
              : field.type === 'boolean'
                ? false
                : field.type === 'text input'
                  ? ''
                  : field.default;
          return field.name;
        }
      });
      if (arr) {
        configObj.channel_id = id;
        return configObj;
      }
    });
    // set this if empty
    assetTypeStore.setConfigs(configData);
    const resultArr = getOptions();
    assetTypeStore.setFieldOptions(resultArr);
  };

  const getOptions = () => {
    const cloneReader = toJS(settingsStore.selectedReader);
    const options = cloneReader.fields.map((field, index) => {
      if (field.name !== 'sample_rate') {
        if (field.type === 'multiple choice') {
          if (field.name === 'coupling') {
            setCouplingIndex(index);
          }
          if (field.name === 'mode') {
            setModeIndex(index);
          }
          return field.values;
        } else {
          return [];
        }
      }
    });
    const tempArr = [];
    if (options) {
      cloneReader.channel_ids.forEach(() => tempArr.push(options));
    }
    return tempArr;
  };
  useEffect(() => {
    if (assetTypeStore.configs && assetTypeStore.configs[0]) {
      const resultArr = getOptions();
      assetTypeStore.setFieldOptions(resultArr);
    }
    if (
      settingsStore.isFirstTime === false &&
      settingsStore.selectedReaderName !== settingsStore.savedReaderName
    ) {
      getData();
    }
    if (settingsStore.selectedReaderName === settingsStore.savedReaderName) {
      assetTypeStore.setConfigs(settingsStore.savedConfigs);
      const resultArr = getOptions();
      assetTypeStore.setFieldOptions(resultArr);
    }
  }, [settingsStore.selectedReaderName]);
  useEffect(() => {
    if (assetTypeStore.configs && assetTypeStore.configs[0]) {
      const resultArr = getOptions();
      assetTypeStore.setFieldOptions(resultArr);
    } else {
      getData();
    }
  }, []);
  return (
    <Table>
      <TableHead>
        <TableRow>
          <TableCell>{locale.getString('settings.channel_selected')}</TableCell>
          <TableCell>{locale.getString('settings.channel_ids')}</TableCell>
          {settingsStore.selectedReader &&
            settingsStore.selectedReader.fields.map((field, index) => {
              if (
                field.is_per_device_channel === true &&
                field.name !== 'channel_selected'
              ) {
                return (
                  <TableCell key={`reader-${field.name}-${index}`}>
                    {locale.getString(`settings.${field.name}`)}
                  </TableCell>
                );
              }
            })}
        </TableRow>
      </TableHead>
      <TableBody>
        {settingsStore.selectedReader &&
          settingsStore.selectedReader.channel_ids.map((id, index) => {
            return (
              <TableRow key={`channel-config-${id}-${index}`}>
                {settingsStore.selectedReader &&
                  settingsStore.selectedReader.fields.map(
                    (field, childIndex) => {
                      if (field.name === 'channel_selected') {
                        return (
                          <TableCell
                            key={`channel-config-${id}-${index}-${childIndex}`}
                          >
                            <Checkbox
                              // id={`${field.name}-${childIndex}-${id}`}
                              name={field.name}
                              onChange={handleToggle(field, index)}
                              checked={
                                assetTypeStore.configs &&
                                assetTypeStore.configs[index]
                                  ? assetTypeStore.configs[index][field.name]
                                  : false
                              }
                            />
                          </TableCell>
                        );
                      }
                    }
                  )}
                <TableCell>{id}</TableCell>
                {settingsStore.selectedReader &&
                  settingsStore.selectedReader.fields.map(
                    (field, childIndex) => {
                      if (
                        field.is_per_device_channel === true &&
                        field.name !== 'channel_selected'
                      ) {
                        return renderRow(field, index, id, childIndex);
                      }
                    }
                  )}
              </TableRow>
            );
          })}
      </TableBody>
    </Table>
  );
};

export default observer(WebDaqTable);
