// import LocaleStore from '@otosense/locale';
import { Box, Button, Grid, TextField, Typography } from '@mui/material';
import LocaleStore from '@otosense/locale';
import { when } from 'mobx';
import { observer } from 'mobx-react-lite';
import React, { ChangeEvent, useEffect, useState } from 'react';
import apiRequest, { APIS } from '../api';
import { useRootContext } from '../RootStore';
import AppState from '../appState';
import ADIlogo from '../assets/OtoSense_logo_black.svg';
import TabletMan from '../assets/tablet-man.svg';
import { PromiseFunction } from '../Utility/types';
import { CoverImg, LoginLeft, LoginRight, LoginLogo } from './styles';

export const Login = () => {
  const root = useRootContext();
  const appState: AppState = root.appState;
  const locale: LocaleStore = appState.locale;
  const [userObj, setUserObj] = useState({
    account: '',
    email: '',
    password: '',
  });
  const [loginDisabled, setLoginDisabled] = useState(true);
  window['loginscreen'] = this;
  const resize = { style: { fontSize: 24, padding: '5px 16px' } };

  useEffect(() => {
    document.title = root.appState.locale.getString('titles.login');
  });

  const login: PromiseFunction = () =>
    appState.login(userObj.account, userObj.email, userObj.password);

  const ready: () => boolean = () =>
    !!userObj.account && !!userObj.email && !!userObj.password;

  const loadDefaults: VoidFunction = () => {
    apiRequest(APIS.GET_DEFAULTS).then((defaults) => {
      if (!defaults || !defaults.account) {
        return;
      } else {
        setUserObj(defaults);
        setLoginDisabled(false);
      }
    });
  };
  const setFieldValue: (
    fieldName: string
  ) => (e: ChangeEvent<HTMLInputElement>) => void =
    (fieldName: string) => (e: ChangeEvent<HTMLInputElement>) => {
      setUserObj({ ...userObj, [fieldName]: e.target.value });
    };

  useEffect(() => {
    when(() => appState.isOnline, loadDefaults);
    setLoginDisabled(appState.isLoading || !ready());
  }, []);

  return (
    <Grid container sx={{ margin: '-24px', width: 'calc(100% + 48px)' }}>
      <LoginLeft item xs={6} p={1}>
        <Box>
          <LoginLogo src={ADIlogo} alt="ADI logo" />
          <Typography variant="h1" component="h1">
            {locale.getString('login.subtitle')}
          </Typography>
          <Typography variant="subtitle2" component="h2" mb={2}>
            {locale.getString('login.version')}: {appState.version}
          </Typography>
          <Typography
            variant="subtitle1"
            mt={1}
            // sx={{ textTransform: 'capitalize' }}
          >
            {locale.getString('literals.account')}
          </Typography>
          <Typography variant="h2" component="h2" sx={{ mb: 1 }}>
            {userObj.account}
          </Typography>
          <Typography
            variant="subtitle1"
            mt={1}
            // sx={{ textTransform: 'capitalize' }}
          >
            {locale.getString('literals.email')}
          </Typography>
          <TextField
            fullWidth
            onChange={setFieldValue('email')}
            value={userObj.email}
            type="email"
            sx={{ width: '100%', mb: 1 }}
            variant="filled"
            inputProps={resize}
          />
          <Typography variant="subtitle1" mt={1}>
            {locale.getString('literals.password')}
          </Typography>
          <TextField
            fullWidth
            variant="filled"
            onChange={setFieldValue('password')}
            value={userObj.password}
            type="password"
            sx={{ width: '100%', mb: 1 }}
            inputProps={resize}
          />

          <Button
            sx={{ mt: 1, fontFamily: 'IBMPlexSans-SemiBold' }}
            variant="contained"
            size="large"
            color="primary"
            onClick={login}
            disabled={loginDisabled}
          >
            {locale.getString('login.login')}
          </Button>
        </Box>
      </LoginLeft>
      <LoginRight item xs={6}>
        <CoverImg src={TabletMan} alt="tablet and a man" />
      </LoginRight>
    </Grid>
  );
};

export default observer(Login);
