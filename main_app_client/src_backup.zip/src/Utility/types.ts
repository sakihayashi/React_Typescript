export type EventHandler = (e: any) => void;
export type RenderFunction = () => JSX.Element;
export type PromiseFunction = () => Promise<any>;
