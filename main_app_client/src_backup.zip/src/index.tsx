import * as React from 'react';
import { render } from 'react-dom';

// import { configure } from 'mobx';
// configure({ enforceActions: 'never' });

import App from './App';

render(<App />, document.getElementById('root'));
