import React from 'react';
import { ThemeProvider } from '@mui/material/styles';
import { otosenseTheme } from '@otosense/components';

import 'material-design-icons/iconfont/material-icons.css';
import './globalStyles/fonts.css';

import Main from './Main';
import rootStore, { RootStoreContext } from './RootStore';

export const App = () => {
  return (
    <ThemeProvider theme={otosenseTheme}>
      <RootStoreContext.Provider value={rootStore}>
        <Main />
      </RootStoreContext.Provider>
    </ThemeProvider>
  );
};

export default App;
