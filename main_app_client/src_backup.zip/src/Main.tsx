import { Backdrop } from '@mui/material';
import CircularProgress from '@mui/material/CircularProgress';
import * as _ from 'lodash';
import { observer } from 'mobx-react-lite';
import React from 'react';
import { useRootContext } from './RootStore';
import AppState, { View } from './appState';
import { MainBlock, MainBody, MainBox } from './styles';
import Toast from './Utility/Toast/Toast';
import * as ViewScreens from './Views';
import HeaderWrapper from './Views/components/HeaderWrapper';
import MenuBar from './Views/components/MenuBar';

export const Main = () => {
  const root = useRootContext();
  const appState: AppState = root.appState;
  let content: JSX.Element;
  let header: JSX.Element;
  let tabsHeader: JSX.Element;

  switch (appState.view) {
  case View.LOGIN:
    content = <ViewScreens.Login />;
    break;
  case View.DATA_COLLECTION_AND_ANALYSIS:
    header = <HeaderWrapper />;
    tabsHeader = <MenuBar />;
    content = <ViewScreens.DataCollection key="oto-screen-content" />;
    break;
  case View.REVIEW_SESSIONS:
    header = <HeaderWrapper />;
    tabsHeader = <MenuBar />;
    content = <ViewScreens.ReviewSessions key="oto-screen-content" />;
    break;
  case View.SETTINGS:
    header = <HeaderWrapper />;
    tabsHeader = <MenuBar />;
    content = <ViewScreens.Settings key="oto-screen-content" />;
    break;
  default:
    content = <ViewScreens.Login />;
    header = null;
    tabsHeader = null;
    break;
  }

  return (
    <MainBox>
      {header}
      <MainBlock>
        {tabsHeader}
        <MainBody>{content}</MainBody>
      </MainBlock>
      <Backdrop
        sx={{ color: '#fff', zIndex: (theme) => theme.zIndex.drawer + 1 }}
        open={appState.isLoading}
      >
        <CircularProgress color="inherit" size={150} />
      </Backdrop>
      {/* {appState.isLoading && (
        <div className="oto-loading oto-loading__screen">
          <div className="oto-loading__loader">
            {locale.getString('global.loadingMessage')}
          </div>
        </div>
      )} */}
      <Toast />
    </MainBox>
  );
};

export default observer(Main);
